import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import test_budget_domestic_archive as native
from polymarket861 import five_league_budget as budget, market_provider as p
out=[]
for n in (0,31,86400):
    with TemporaryDirectory() as tmp:
        root=Path(tmp); orig=native.reply
        def make(obj,when,url):
            r=orig(obj,when,url)
            return p.Reply(r.body,r.requested_at,r.received_at,r.headers | ({'age':str(n)} if 'gamma-api.polymarket.com' in url else {}),r.url)
        with patch.object(native,'reply',side_effect=make): doc, _=native.domestic_entry(root,'sea')
        s=budget.replay(doc,data_dir=root,entry_basis='scheduled_with_incomplete_flags',details=True);out.append({'age_seconds_on_gamma':n,'outcome':s['leagues']['sea']['outcomes'],'basis':(s['decisions'][0]['entry_evidence'] or {}).get('basis'),'gaps':s['proof_gaps']})
print(json.dumps(out,indent=2))
