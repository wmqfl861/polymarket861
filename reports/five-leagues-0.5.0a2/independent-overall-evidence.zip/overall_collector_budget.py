"""Offline controlled clock/transport. Source-shaped synthetic cases, never a historical trading observation."""
import json,sys,tempfile,sqlite3
from contextlib import ExitStack,closing
from datetime import timedelta
from email.utils import format_datetime
from pathlib import Path
from unittest.mock import patch
from urllib.parse import urlencode
from polymarket861 import archive_proof,big5_market as big,budget_archive_proof as proof,ledger_terms,market_archive as arch,market_provider as prov,five_league_budget as budget,store

src=Path(sys.argv[1]); out=[]
with proof.read_archive(src) as (root,native):
    slugs=[r[0] for r in native.execute("SELECT fixture FROM big5_events GROUP BY sport ORDER BY sport")]
    material={}
    for slug in slugs:
        material[slug]=[archive_proof._event_capture(native,root,r['sha'],r['received_at'],r['slug']) for r in native.execute('SELECT slug,received_at,sha FROM ma_events WHERE fixture=? GROUP BY slug ORDER BY slug',(slug,))]

def run(slug, originals, fee_mode):
    sport=slug.split('-')[0]; events=json.loads(json.dumps(originals)); kick=store.instant(events[0]['startTime']); decision=kick-timedelta(hours=1)
    condition=next(m['conditionId'] for m in events[0]['markets'] if m['slug']==slug+'-draw')
    tmap={}
    for event in events:
        for m in event['markets']:
            tokens=prov.sequence(m.get('positionIds' if m.get('version')=='v2' else 'clobTokenIds')); tmap.update({str(i):m['conditionId'] for i in tokens});
            if fee_mode=='synthetic_disabled': m.update(feesEnabled=False); m.pop('feeSchedule',None)
    dates=(store.iso(kick-timedelta(hours=3)),store.iso(kick+timedelta(hours=2)))
    with tempfile.TemporaryDirectory() as tmp:
        base=Path(tmp); destination=big.research_root(base); report=[]
        horizon=max(5,next(m['secondsDelay'] for m in events[0]['markets'] if m['conditionId']==condition)); offsets=(-10,horizon+1)
        for offset in offsets:
            time=decision+timedelta(seconds=offset); stamp=store.iso(time)
            def transport(url,params=None,**kw):
                full=url; opts=params or {}
                if url.endswith('/sports'):
                    series,tag=big.MARKETS[sport]; payload=[{'sport':sport,'series':series,'tags':tag,'primaryTagId':tag}]
                elif url.endswith('/events'):
                    payload=events[opts['offset']:opts['offset']+opts['limit']]; full+=('?'+urlencode(opts))
                elif '/events/slug/' in url:
                    payload=next(e for e in events if e['slug']==url.split('/')[-1]);
                elif url.endswith('/books'):
                    payload=[{'asset_id':tok,'market':tmap[tok],'timestamp':str(int(time.timestamp()*1000)),'hash':f'{offset}-{tok}','bids':[{'price':'0.49','size':'1000'}],'asks':[{'price':'0.50','size':'1000'}],'tick_size':'0.01','min_order_size':'1'} for tok in opts['token_ids']]
                else: raise AssertionError(url)
                return prov.Reply(json.dumps(payload).encode(),stamp,stamp,{'date':format_datetime(time)},full)
            with ExitStack() as env:
                for mod in (store,big,arch): env.enter_context(patch.object(mod,'now_utc',return_value=stamp))
                env.enter_context(patch.object(prov,'get',side_effect=transport)); big.catalog(base,[sport],*dates); watch=big.watch(base,[sport],*dates,discover=False); report.append(watch['states'])
        with proof.read_archive(base) as (dr,db):
            m=archive_proof.original_market(db,dr,condition,decision); token=m['tokens'][0]['token_id']; fields=big._identity(events[0],sport); fixture=f'{sport}/2026-27/{fields[4]}/{fields[5]}'
            try: terms=ledger_terms.from_original(dr,m,token,decision)
            except ValueError as exc: return {'league':sport,'fee_mode':fee_mode,'watch_states':report,'fee_authority_gap':str(exc)}
            idx=[json.loads(r[0]) for r in db.execute('SELECT payload FROM ma_books WHERE token=? ORDER BY received_at',(token,))]
            booklist=[{'id':str(i),'fixture_id':fixture,'condition_id':condition,'token_id':token,'received_at':b['received_at'],'source_sha256':b['source_sha256'],'asks':b['asks']} for i,b in enumerate(idx)]
            original_ops=[r[0] for r in db.execute('SELECT DISTINCT operation FROM ma_requests ORDER BY operation')]
        op={'id':'holding','fixture_id':fixture,'condition_id':condition,'token_id':token,'rank':0,'decision_at':store.iso(decision),'kickoff':store.iso(kick),'decision_book':'0','execution_book':'1','shares':'100','limit_price':'0.5','selection':{k:terms[k] for k in ('family','selection','team','line','side') if k in terms},'rule_sha256':terms['rule_sha256'],'fee':terms['fee_schedule']}
        doc={'schema':budget.SCHEMA,'evidence_mode':'local_receipts','intents':[op],'books':booklist,'originals':{},'redemptions':[]}
        strict=budget.replay(doc,data_dir=base); study=budget.replay(doc,data_dir=base,details=True,entry_basis='scheduled_with_incomplete_flags'); tested=study['decisions'][0]
        return {'league':sport,'fee_mode':fee_mode,'domestic_fixture':slug,'watch_states':report,'actual_operations_in_controlled_db':original_ops,'matched_book_count':len(booklist),'flag':tested['entry_evidence']['basis'] if tested['entry_evidence'] else None,'default':strict['leagues'][sport]['outcomes'],'research':study['leagues'][sport]['outcomes'],'research_gaps':study['proof_gaps'],'book_hashes':[b['source_sha256'] for b in booklist],'verified_venue_orders':study['verified_orders_at_venue']}
for slug,raw in material.items():
    for fee in ('as_seen_in_real_metadata','synthetic_disabled'):out.append(run(slug,raw,fee))
print(json.dumps({'scope':'Controlled fixture clocks and original-format CLOB stubs. Candidate Gamma fields seeded by recorded public events; zero actual decision/exit slots or executions are implied.', 'cases':out},indent=2,ensure_ascii=False))
