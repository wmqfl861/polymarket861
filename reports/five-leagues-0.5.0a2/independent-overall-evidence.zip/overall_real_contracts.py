import collections, json, pathlib, sqlite3, sys
from polymarket861 import archive_proof as api, budget_archive_proof as budget
for s in sys.argv[1:]:
    path=pathlib.Path(s); acc=collections.Counter(); errors=collections.Counter(); cases=[]; flags=collections.Counter(); contracts=collections.Counter(); kinds=collections.Counter()
    with budget.read_archive(path) as (root,db):
        for row in db.execute('SELECT slug,received_at,sha FROM ma_events GROUP BY slug ORDER BY slug'):
            event=api._event_capture(db,root,row['sha'],row['received_at'],row['slug']); flags[tuple(str(event.get(k)) for k in ('live','ended','gameStatus','status'))]+=1
        rows=db.execute('SELECT event_slug,market_slug,received_at,sha,payload FROM ma_contracts ORDER BY event_slug,market_slug,received_at').fetchall(); seen=set()
        for row in rows:
            m=json.loads(row['payload']); key=m['condition_id']; league=m['fixture'].split('-')[0];
            if not key or (key,league) in seen: continue
            seen.add((key,league)); contracts[league]+=1
            try:
                out=api.original_market(db,root,key,row['received_at']); evidence=(len(out['tokens'])==2 and key==out['condition_id'] and row['sha']==out['source_sha256'] and len(out['event_teams'])==2)
                acc[(league,evidence)]+=1
                kinds[('fee '+str(out['fees_enabled']),league)]+=1
                if len(cases)<5: cases.append([league,key,out['source_sha256'],out['slug']])
            except Exception as exc: errors[(league,str(exc))]+=1
        dates=db.execute('SELECT MIN(received_at),MAX(received_at) FROM ma_books').fetchone(); books=db.execute('SELECT COUNT(*) FROM ma_books').fetchone()[0]; stages=[tuple(r) for r in db.execute('SELECT phase,COUNT(*) FROM big5_runs GROUP BY phase')]
        print(json.dumps({'archive':s,'contracts':dict(contracts),'validated':{repr(k):v for k,v in acc.items()},'issues':{repr(k):v for k,v in errors.items()},'flags_in_first_event_receipt':{repr(k):v for k,v in flags.items()},'book_rows':books,'book_range':list(dates),'run_types':stages,'fee_switch':{repr(k):v for k,v in kinds.items()},'examples':cases},ensure_ascii=False))
