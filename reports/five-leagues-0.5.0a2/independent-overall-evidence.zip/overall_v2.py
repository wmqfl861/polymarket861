import collections, json
import numpy as np
from scipy.stats import t
from polymarket861 import news_endpoint_v2 as v2, news_endpoint_study as v1
points=[]; cells=[]; modes=('technical','formal')
for modei,mode in enumerate(modes):
    for erai in range(2):
        era=chr(97+erai)*64
        for r in range(1,9):
            index=modei*2+erai; x=.016*(r%3-1)+.009*index+.00019*r; e=.005*np.cos(r*.8+index); y=.72*x +.011*(index-1.5)+e
            points.append([index,r,x,y]); cells.append({'mode':mode,'implementation':era,'season':'2026-27','round_id':r,'dual_schedule_close':{'endpoints':{'home_win':{'no_news':.4,'with_news':float(.4+x),'close':float(.4+y)}}}})
design=np.array([[float(int(a==i)) for i in range(4)]+[x] for a,r,x,y in points]); y=np.array([p[-1] for p in points]); beta=np.linalg.lstsq(design,y,rcond=None)[0]; inv=np.linalg.inv(design.T@design); res=y-design@beta; meat=np.zeros((5,5)); g=len(set(p[1] for p in points)); n=len(points)
for rnd in range(1,g+1):
    idx=[i for i,p in enumerate(points) if p[1]==rnd]; score=design[idx].T@res[idx];meat+=np.outer(score,score)
se=float(np.sqrt((inv@meat@inv)[-1,-1]*(g/(g-1))*(n-1)/(n-5))); critical=float(t.ppf(1-.025/14,g-1)); expected=[float(beta[-1]),se,float(beta[-1]-critical*se),float(beta[-1]+critical*se)]; pre=v2._slope_cell(cells,'dual_schedule_close','home_win',False); post=v2._slope_cell(cells,'dual_schedule_close','home_win',True); actual=[post['slope'],post['interval']['standard_error'],post['interval']['lower'],post['interval']['upper']]; assert np.max(np.abs(np.array(expected)-np.array(actual)))<1e-13; assert pre['slope'] is None and pre['interval'] is None and not any('informative_pairs' in g for g in pre['strata']); row={'sealed':False,'seal':'original','study_status':'declared','reason':'invalid_seal_or_archived_evidence','study_plan_sha256':v1.PLAN['native_pair_declaration_sha256'],'implementation':'b'*64,'news_protocol':'a','policy_sha256':'0'*64,'timely_news_coverage':True,'input_cutoff':'b','kickoff':'f'}; reason=v2._mismatch(row,{'seal':'original','probability_era':'b'*64,'bound_at':'c','cutoff':'d'},{'starts_at':'a','news_policy':{'protocol':'a','sha256':'0'*64}}); assert reason=='invalid_seal_or_archived_evidence'
print(json.dumps({'disclosure':'synthetic observations','matches':n,'strata':4,'rounds':g,'family':v2.FAMILY,'ols_se_lower_upper':expected,'package_slope_se_lower_upper':actual,'max_difference':float(np.max(np.abs(np.array(expected)-np.array(actual)))),'blinded_slope':pre['slope'],'blinded_interval':pre['interval'],'late_validation_failure':reason},indent=2))
