import json,sys
from pathlib import Path
from unittest.mock import patch
from polymarket861 import news_endpoint_study as v,store
x=json.loads(Path(sys.argv[1]).read_bytes());
with patch.object(store,'now_utc',return_value=x['as_of']): o=v.report(x['data_dir'])
print(json.dumps({'ok':o==x['old_report'],'study_report_sha':store.digest(o),'registered':o['registration']['registration_sha256'],'qualified_now':o['horizons']['T-60m']['qualified_news_pairs'],'original_fields':len(o),'bound':o['bound_seals'],'plan_sha':o['plan_sha256'],'file_sha': __import__('hashlib').sha256(v._TRIGGER.encode()).hexdigest()}, indent=2)); assert o==x['old_report']
