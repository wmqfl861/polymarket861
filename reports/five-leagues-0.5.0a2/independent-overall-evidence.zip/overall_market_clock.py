import json
from datetime import timedelta
from test_big5_receipt_grades import TestDomesticReceiptGrades,CUTOFF,STRONG
from polymarket861 import store
normal = ({},{}); revised={'startTime':store.iso(CUTOFF+timedelta(hours=2))}
scenarios = {'normal':(), 'prior_live':((-15,{'live':True},{}),), 'prior_game_status':((-15,{'gameStatus':'In Progress'},{}),), 'aux_temporary_reschedule_between_legs':((1,{},revised),(3,{},{})), 'main_temporary_reschedule_between_legs':((1,revised,{}),(3,{},{})), 'both_temporary_reschedule_between_legs':((1,revised,revised),(3,{},{})), 'postponed_then_restored_between_legs':((1,{'status':'postponed'},{}),(3,{},{})), 'live_then_restored_between_legs':((1,{'live':True},{}),(3,{},{}))}
result={}
for name, edits in scenarios.items():
    c=TestDomesticReceiptGrades('test_type_and_status_evidence'); c.setUp()
    try:
        for offset,main,aux in sorted(((-30,{},{}),(-10,*normal),(6,*normal),*edits)):
            c._leg(offset,main,aux,watch=offset in (-10,6))
        stats=c._counts()
        result[name]={k:stats.get(k,0) for k in ('fixed_windows_due','fixed_windows_complete','fixed_windows_schedule_only','t1_pairs_due','t1_pairs_complete','t1_pairs_schedule_only','t1_pairs_not_pregame','t1_pairs_unclassified')}
    finally: c.doCleanups()
print(json.dumps(result,indent=2))
