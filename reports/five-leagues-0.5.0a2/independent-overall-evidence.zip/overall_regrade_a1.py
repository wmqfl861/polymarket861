import json,pathlib,sys
from unittest.mock import patch
from polymarket861 import big5_market as b
stamp='2030-01-12T13:02:00.000000Z'
old=json.load(open(sys.argv[2])); result=[]
with patch.object(b,'now_utc',return_value=stamp):
    for i, (name, prior) in enumerate(old.items()):
        p=pathlib.Path(sys.argv[1])/f'arm{i}'; current=b.weekly_report(p,'2030-01-12T12:59Z','2030-01-12T13:01Z')['by_league']['sea']; result.append({'state':name,'actual_native_book_count':prior['archived_books'],'a1':{k:prior[k] for k in ('fixed_windows_complete','t1_pairs_complete')},'a2':{k:v for k,v in current.items() if k.startswith('fixed_windows') or k.startswith('t1_pairs')}})
print(json.dumps(result,ensure_ascii=False,indent=2))
