import json
from datetime import timedelta
from test_news_endpoint_reference_v2 import DualScheduleEndpoints
case = DualScheduleEndpoints('test_both_horizons_use_native_signatures_missing_flags_and_asof_early_proof')
case.setUp()
try:
    case.batch(case.stamps[0]); case.schedules(case.kick-timedelta(hours=2)); case.batch(case.stamps[1]); case.batch(case.close,shift=2); case.scores()
    summary = {}
    def obs(name):
        result=case.observation(case.cutoffs[0]); summary[name] = {'endpoints':sorted(result.get('endpoints',{})), 'reason':result.get('reason'), 'missing':result.get('missing')}
    obs('control')
    case.gamma(case.kick-timedelta(seconds=48),case.event | {'gameStatus':'In Progress'})
    obs('native_in_progress_3s_before_closing_book')
    case.gamma(case.kick-timedelta(seconds=46),case.event | {'status':'postponed'})
    obs('plus_postponed')
    case.gamma(case.kick-timedelta(seconds=44),case.event | {'live':True})
    obs('plus_native_live_boolean')
    print(json.dumps(summary, indent=2))
finally:
    case.doCleanups()
