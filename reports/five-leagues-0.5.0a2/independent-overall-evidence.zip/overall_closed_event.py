from test_budget_scheduled_entry import capture,replay
from test_big5_receipt_grades import TestDomesticReceiptGrades
from test_news_endpoint_reference_v2 import DualScheduleEndpoints
from pathlib import Path
from tempfile import TemporaryDirectory
from datetime import timedelta
import json
out=[]
for fields in ({'closed':True},{'archived':True},{'active':False}):
    with TemporaryDirectory() as folder:
        root=Path(folder);doc,_=capture(root,fields); report=replay(root,doc); cash=report['leagues']['epl']['outcomes']
    c=TestDomesticReceiptGrades('test_type_and_status_evidence'); c.setUp()
    try:
        c._leg(-10,fields,fields); c._leg(6,fields,fields); week=c._counts()
    finally:c.doCleanups()
    n=DualScheduleEndpoints('test_both_horizons_use_native_signatures_missing_flags_and_asof_early_proof'); n.setUp()
    try:
        n.batch(n.stamps[0]); n.schedules(n.kick-timedelta(hours=2)); n.batch(n.stamps[1]); n.batch(n.close,shift=2); n.scores(); n.gamma(n.kick-timedelta(seconds=48),n.event|fields); obs=n.observation(n.cutoffs[0]);
    finally:n.doCleanups()
    out.append({'native_fields':fields,'paper':cash,'weak_fixed_pairs':week.get('t1_pairs_schedule_only',0),'weak_news_endpoints':list(obs.get('endpoints') or {}),'news_reason':obs.get('reason')})
print(json.dumps(out,indent=2))
