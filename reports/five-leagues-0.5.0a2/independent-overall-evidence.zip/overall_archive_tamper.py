import json,sqlite3,shutil,pathlib,sys,tempfile
from unittest.mock import patch
from contextlib import closing
from polymarket861 import big5_market as b,store
src=pathlib.Path(sys.argv[1]); results={}
with tempfile.TemporaryDirectory() as p:
    parent=pathlib.Path(p);root=b.research_root(parent); shutil.copytree(b.research_root(src),root)
    def stats():
        with patch.object(b,'now_utc',return_value='2030-01-12T13:02:00.000000Z'):
            r=b.weekly_report(parent,'2030-01-12T12:59Z','2030-01-12T13:01Z');c=r['by_league']['sea'];return {k:c.get(k) for k in ('fixed_windows_complete','fixed_windows_explicit_pregame','fixed_windows_schedule_only','t1_pairs_complete','t1_pairs_schedule_only')}|{'missing_objects':r['raw_missing_bodies']}
    results['original_a1']=stats();
    with closing(sqlite3.connect(root/'runtime.sqlite3')) as db,db:
        db.execute("UPDATE big5_slots SET success=1,report='{}'"); sha=db.execute('select sha from ma_books order by received_at desc limit 1').fetchone()[0]
    results['invent_new_slot_success']=stats();native=store.blob_path(root,sha); retained=native.read_bytes(); native.unlink(); results['remove_one_native_batch']=stats();native.write_bytes(retained);results['restore']=stats();
assert results['original_a1']==results['invent_new_slot_success']==results['restore'];assert results['remove_one_native_batch']['fixed_windows_complete']==1 and results['remove_one_native_batch']['t1_pairs_complete']==0
print(json.dumps(results,indent=2))
