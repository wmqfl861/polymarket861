from collections import Counter
from pathlib import Path
from tempfile import TemporaryDirectory
import json, shutil
from polymarket861 import news_endpoint_v2 as v2
from test_news_endpoints_v2 import capture_clock
from test_news_matchday import KICKOFF
from test_paired_proof import at

root=Path(__file__).resolve().parent
source=root.parent/'news-sources'
read=lambda p:json.loads(p.read_bytes())
global_survey=read(source/'wire.json')['injuries']
earlier=read(Path('reports/five-leagues-0.5.0a2/news-source-retention-coverage.json'))
assert sum(earlier['weights_per_seal'])==earlier['by_origin']['touchlinewire.com']==90
assert sum(global_survey['category_counts'].values())==global_survey['rows']==92
facts=[f for path in sorted(source.glob('facts-*.json')) for f in read(path)['facts']]
with TemporaryDirectory(dir=root) as path,capture_clock(),at(KICKOFF):
 data=Path(path)/'data'
 shutil.copytree(root.parent/'news-pref-native/registered/store',data)
 r=v2.report(data)['horizons']['T-60m']
 books={clock:{ep:cell['pairs'] for ep,cell in cells.items()} for clock,cells in r['clocks'].items()}
 assert r['qualified_news_pairs']==1 and r['score_guardrail']['pairs']==0 and all(count==0 for group in books.values() for count in group.values())
 print(json.dumps({'controlled_pregame':{'news_pairs':r['qualified_news_pairs'],'book_pairs':books,'score_guardrail_pairs':r['score_guardrail']['pairs']},'match_snapshots_facts_by_event':Counter(f['event'] for f in facts),'separate_a2_early_seals':{'counts':earlier['weights_per_seal'],'fixtures':earlier['with_applied_touchline'],'weighted':sum(earlier['weights_per_seal'])},'global_aggregate_only':{'rows':global_survey['rows'],'category_counts':global_survey['category_counts'],'suspensions_with_scope':global_survey['suspensions_with_suspension_competition'],'injuries_with_onset':global_survey['injuries_with_injury_started_at_or_injury_date'],'full_response_archived':global_survey['full_response_retained']}},indent=2))
