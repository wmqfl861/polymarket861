"""Clone the second native mode to isolate which receipt is selected before inspecting evidence."""
import json, sqlite3, shutil, tempfile, sys
from pathlib import Path
from contextlib import closing
from polymarket861 import news_endpoint_preflight as pf, news_endpoint_v2 as v2,store
from test_news_endpoints_v2 import capture_clock
from test_paired_proof import at
from test_news_matchday import KICKOFF

base=Path(__file__).resolve().parent
src=Path(sys.argv[1]).resolve()
def seen(path):
    p=pf.preflight(path)
    return {k:p[k] for k in ('fixed_windows_total','fixed_windows_checked','news_evidence_counts')} | {'winner':[(x['seal'],x['news_evidence']) for x in p['windows']]}
with tempfile.TemporaryDirectory(dir=base) as tmpdir, capture_clock(), at(KICKOFF):
    root=Path(tmpdir)/'store'
    shutil.copytree(src,root)
    with closing(sqlite3.connect(root/'runtime.sqlite3')) as c,c:
        c.row_factory=sqlite3.Row
        first=c.execute('select * from forecast_seals').fetchone()
        z=json.loads(first['data_json']); z['mode']='formal'
        second=store.digest(z)
        fields=dict(first);fields.update(mode='formal',digest=second,data_json=store.canonical(z))
        c.execute("insert into forecast_seals values (?,?,?,?,?,?,?,?,?,?)",tuple(fields.values()))
        expected=c.execute('select capture_order,seal from news_endpoint_v2_bindings order by capture_order').fetchall()
        records={'captures':[dict(x) for x in expected]}
    records['before']=seen(root)
    with closing(sqlite3.connect(root/'runtime.sqlite3')) as c,c:
        c.execute("update forecast_seals set data_json=json_remove(data_json,'$.purpose') where digest=?",(first['digest'],))
    records['first_loses_purpose']=seen(root)
    r=v2.report(root)
    records['registered_report']={k:r['horizons']['T-60m'][k] for k in ('past_scheduled_windows','qualified_news_pairs','duplicate_bindings_ignored','strata','exclusions')}
    print(json.dumps(records,indent=2))
