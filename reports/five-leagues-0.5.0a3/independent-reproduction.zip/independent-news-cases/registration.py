"""Compare whole a2 envelopes, a punctuation-only drift and genuine persisted corruption."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from contextlib import closing
import copy, hashlib,json,sqlite3,shutil
from polymarket861 import news_endpoint_v2 as v2,news_endpoint_study as v1,news_endpoint_preflight as pre,store
from test_news_endpoints_v2 import cli
work=Path(__file__).resolve().parent
repo=Path.cwd()
load=lambda p: json.loads(p.read_bytes())
pin='3db775698c93664b5ba749be8a03f94f75940f212438849ad63e4cf672002a61'
canonical=lambda o: json.dumps(o,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf8')
def fingerprint(o): return hashlib.sha256(canonical(o)).hexdigest()
def message(f):
 try: f()
 except ValueError as e:return str(e)
 raise AssertionError("expected an explicit rejection")
def hash_db(r):return hashlib.sha256((r/'runtime.sqlite3').read_bytes()).hexdigest()
a2=load(repo/'reports/five-leagues-0.5.0a2/news-endpoint-study-v2.json')
public=a2['plan']
cert=load(work.parent/'news-v2-before/reg2.json')
assert pin==fingerprint(public)==a2['plan_sha256']
assert fingerprint({k:y for k,y in cert.items() if k!='registration_sha256'})==cert['registration_sha256']
changed=copy.deepcopy(public);changed['reporting']=changed['reporting'].replace('end publish','end, publish')
drift=fingerprint(changed);assert drift=='5ead6f2492d7328b4cdbab5110a877900ec30506d71449e93948a4e39a5948a7'
with TemporaryDirectory(dir=work) as t:
 root=Path(t)/'data';shutil.copytree(work.parent/'news-v2-before/data',root)
 old=hash_db(root)
 assert cli(root,'register','--version','v2')==cert
 assert old==hash_db(root)
 assert cli(root,'report','--version','v2')['registration']==cert
 result={'frozen_plan_and_108_cells':pin,'a2_certificate_sha':cert['registration_sha256'],'repeated_enrollment_returns_same_certificate':True,'main_db_equal_after_operations':old==hash_db(root),'punctuation_only':drift}
 with patch.object(v2,'proposal',return_value={'plan':changed,'plan_sha256':drift}):
    result['installed_drift']={act:message(lambda:cli(root,act,'--version','v2')) for act in ('report','register','preflight','plan')}
 assert old==hash_db(root) and cli(root,'report','--version','v2')['registration']==cert
 new={k:y for k,y in cert.items() if k!='registration_sha256'}|{'plan':changed,'plan_sha256':drift}
 def update_manifest(d, data):
    with closing(sqlite3.connect(root/'runtime.sqlite3')) as c,c:
        c.execute("update news_endpoint_declarations set digest=?,manifest=? where version=?",(d,data,v1.V2_VERSION))
 update_manifest(fingerprint(new),canonical(new).decode())
 result['unsupported_prior_design']=message(lambda:pre.preflight(root))
 new['plan_sha256']=pin
 update_manifest(fingerprint(new),canonical(new).decode())
 result['corrupt_plan_with_consistent_envelope']=message(lambda:pre.preflight(root))
 update_manifest('f'*64,'[]')
 result['corrupt_certificate']=message(lambda:pre.preflight(root))
 print(json.dumps(result,indent=2))
