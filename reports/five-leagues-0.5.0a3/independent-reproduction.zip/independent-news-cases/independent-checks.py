"""Independent read-only/source/timing checks. Run from a source checkout with src:tests in PYTHONPATH."""
from contextlib import closing
from collections import Counter
from datetime import timedelta
from pathlib import Path
import copy, hashlib, json, shutil, sqlite3, tempfile, os
from unittest.mock import patch
from polymarket861 import news_endpoint_preflight as p, news_endpoint_v2 as v, news_endpoint_study as s, news_endpoint_originals as o, news, news_study_plan, store
from polymarket861.blob_storage import blob_path
from test_news_endpoints_v2 import capture_clock
from test_news_endpoint_study import raw_seal
from test_paired_proof import at
from test_news_matchday import KICKOFF

outbase=Path(__file__).resolve().parent
samples=outbase.parent
repo=Path.cwd()
read=lambda x:json.loads(Path(x).read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def signature(root): return {str(x.relative_to(root)):sha(x) for x in sorted(root.rglob('*')) if x.is_file() and x.suffix not in ('.sqlite3-shm','.sqlite3-wal')}
def one(r):
    z=p.preflight(r)
    return {'state':z['registration']['state'],'total':z['fixed_windows_total'],'evidence':[(x.get('seal'),x['news_evidence'],x.get('known_blockers',[])) for x in z['windows']],'future_eligible_windows':z['future_eligible_windows']}
def db(root):
    c=sqlite3.connect(root/'runtime.sqlite3'); c.row_factory=sqlite3.Row;return c
def query(root,sql,param=()):
    with closing(db(root)) as c:
        return dict(c.execute(sql,param).fetchone())

record={}
with tempfile.TemporaryDirectory(dir=outbase) as d:
    dest=Path(d)
    empty=dest/'empty'
    diag=p.preflight(empty)
    record['new_path']=[empty.exists(),diag['decision'],diag['future_eligible_windows']]
    assert not empty.exists() and diag['fixed_windows_total']==0 and diag['future_eligible_windows'] is None
    old=dest/'old'; shutil.copytree(samples/'news-v2-before/data',old)
    cert=read(samples/'news-v2-before/reg2.json')
    old_sha=signature(old)
    original=p.preflight(old)
    r=v.report(old)
    assert original['registration']['registration_sha256']==cert['registration_sha256'] and r['registration']==cert and cert['plan']==v.published_proposal()['plan']
    assert old_sha==signature(old)
    record['a2_read_only']={'published_sha256':v.PUBLISHED_PLAN_SHA256,'power_cells':len(cert['plan']['planning_power'].get('cells',[])),'same_entire_certificate':r['registration']==cert,'same_plan':True,'all_existing_application_files_and_main_db_hashes_identical':True,'file_count':len(old_sha),'fixed_windows':original['fixed_windows_total'],'bound':r['bound_seals']}
    # A separate call to register on the isolated copy returns the same certificate.
    assert v.enroll(old)==cert
    absent=dest/'unregistered';shutil.copytree(samples/'news-pref-native/subscribed-no-registration/store',absent)
    with at(KICKOFF):
        before=one(absent)
        with capture_clock():
            v.enroll(absent)
            after=one(absent)
            assert v.report(absent)['bound_seals']==0
    assert before['evidence'][0][1]=='unknown' and after['evidence']==before['evidence']
    record['no_retroactive_binding']=[before,after]
    reg=dest/'registered';shutil.copytree(samples/'news-pref-native/registered/store',reg)
    source=query(reg,"select * from news_endpoint_v2_poll_originals where source='arsenal-bulletins'")
    raw=blob_path(reg,source['response_sha'])
    with capture_clock(),at(KICKOFF):
        before_sig=signature(reg)
        good=one(reg)
        assert good['evidence'][0][1]=='bound_news_originals_verified' and signature(reg)==before_sig
        original_bytes=raw.read_bytes()
        raw.unlink()
        missing=one(reg)
        raw.parent.mkdir(exist_ok=True)
        raw.write_bytes(original_bytes+b'bad')
        bad=one(reg)
        raw.write_bytes(original_bytes)
        assert good==one(reg)
        assert missing['evidence'][0][1]=='expected_ineligible' and bad['evidence'][0][1]=='expected_ineligible'
        record['original_file']={'native_good':good['evidence'][0][1],'physical_bytes_absent':missing['evidence'][0][1:],'sha_mismatch':bad['evidence'][0][1:],'restored_original':one(reg)['evidence'][0][1],'data_and_content_hashes_equal_across_preflight':True}
        # Keep the v2 response in its own table but change the observation registration. V1's
        # physical proof cannot compensate. The temp scope should expose no such receipt.
        with closing(db(reg)) as c,c:
            c.execute("update news_endpoint_v2_poll_originals set document=json_set(document,'$.metadata.registration',?) where source='arsenal-bulletins'",('f'*64,))
        foreign=one(reg)
        assert foreign['evidence'][0][1]=='expected_ineligible'
        record['foreign_original']=foreign['evidence'][0][1:]
        with closing(db(reg)) as c,c:
            c.execute('update news_endpoint_v2_poll_originals set document=? where receipt=?',(source['document'],source['receipt']))
        # Make a response carry a future retention timestamp; do not accept it if its raw bytes exist today.
        with closing(db(reg)) as c,c:
            c.execute("update news_endpoint_v2_poll_originals set document=json_set(document,'$.metadata.recorded_at',?) where receipt=?",('2026-08-13T00:00:00.000000Z',source['receipt']))
        after_cut=one(reg)
        assert after_cut['evidence'][0][1]=='expected_ineligible'
        record['future_retention']=after_cut['evidence'][0][1:]
    with capture_clock(),at('2026-08-12T12:55:00Z'):
        early=one(reg);assert early['total']==0
    record['before_seal_time']=early
    # Older dates and foreign, special-purpose, late and after-end rows never supply denominators.
    scope=dest/'scope';stamp=store.instant('2027-08-10T10:00Z')
    oldstamp=stamp-timedelta(days=366)
    with closing(store.connect(scope)) as c,c:
        first=raw_seal(c,'epl/2026-27/in-1/home',oldstamp)
        raw_seal(c,'epl/2026-27/in-1/home',oldstamp,mode='formal',era='b'*64)
        second=raw_seal(c,'epl/2027-28/in-2/home',stamp,season='2027-28')
        raw_seal(c,'epl/2025-26/wrong/home',oldstamp,season='2025-26')
        raw_seal(c,'epl/2028-29/wrong/home',oldstamp,season='2028-29')
        raw_seal(c,'lal/2026-27/wrong/home',oldstamp)
        raw_seal(c,'epl/2027-28/future/home',stamp+timedelta(days=20),season='2027-28')
        raw_seal(c,'epl/2027-28/after-end/home',store.instant('2028-07-01T00:00Z'),season='2027-28')
        raw_seal(c,'epl/2027-28/candidate/home',stamp,season='2027-28',purpose='candidate')
        raw_seal(c,'epl/2027-28/replay/home',stamp,season='2027-28',mode='replay')
    with at(stamp+timedelta(days=1)):
        whole=p.preflight(scope); limited=p.preflight(scope,limit=1)
        assert {i['seal'] for i in whole['windows']}=={first,second} and limited['fixed_windows_total']==2 and limited['fixed_windows_checked']==1 and limited['windows'][0]['seal']==second
    record['scope']={'present':[(i['fixture_id'],i['news_evidence']) for i in whole['windows']],'count_at_limit_one':limited['fixed_windows_total'],'checked_at_limit_one':limited['fixed_windows_checked'],'no_future_eligible_count':whole['future_eligible_windows']}
    # Copy the actual snapshots. Count the endpoint's independent national / per-match / local scope separately.
    live=samples/'news-sources'
    obs=read(repo/'reports/five-leagues-0.5.0a3/news-source-readiness.json')
    x=obs['initial_cli_collection']
    docs=[read(f) for f in sorted(live.glob('facts-*.json'))]
    facts=[f for doc in docs for f in doc['facts']]
    assert len(facts)==x['news_facts_total']==100 and len(set(f['player_id'] for f in facts))==97
    assert dict(Counter(f['event'] for f in facts))==x['facts_by_event']
    assert len({doc['fixture_id'] for doc in docs})==10
    licenses=obs['english_wikipedia_source_responses']['clubs']
    for item in licenses:
        name=item['permanent_revision_url'].split('=')[-1]+'.json'
        assert sha(live/'wiki'/name)==item['response_sha256']
    rt=dest/'real-capture';shutil.copytree(live/'state',rt)
    second=read(live/'second-forest-chelsea-facts.json')
    as_of=second['cutoff'];fixture={'fixture_id':second['fixture_id'],'season':'2026-27','kickoff':second['schedule']['kickoff']}
    cfg=read(live/'sandbox-only-registration.json')
    with closing(sqlite3.connect((rt/'runtime.sqlite3').resolve().as_uri()+'?mode=ro',uri=True)) as c:
        c.row_factory=sqlite3.Row;c.execute('BEGIN');s._scope_fixture_history(c,as_of);o.scope_originals(c,o.V2_ORIGINALS,cfg['registration_sha256'])
        firstcut=max(doc['cutoff'] for doc in docs)
        receipts=c.execute("select json_extract(payload,'$.source'),count(*),count(distinct json_extract(payload,'$.team')) from news_poll_proofs where json_extract(payload,'$.observed_at')<=? group by 1",(firstcut,)).fetchall()
        rows=list(c.execute('select * from news_endpoint_poll_originals order by observed_at'))
        cache={}; decoded=Counter()
        for row in rows:
            m=json.loads(row['document'])
            _,parsed,config=o._verified_poll(c,rt,row['receipt'],row['season'],m['config']['team'],row['source'],as_of,cache)
            decoded[(config['id'],'initial' if parsed.get('baseline_only') else 'subsequent')]+=1
        assert sum(n for _,n,_ in receipts)==60 and all(n==teams==20 for _,n,teams in receipts)
        assert dict(decoded)=={('wikipedia-season-news','initial'):20,('wikipedia-season-news','subsequent'):2}
        ctr=Counter();rosters=set();teamchecks=[]
        for side in ('home','away'):
            info=second['coverage'][side];src=next(a for a in info['sources'] if a['id']=='wikipedia-season-news')
            o._roster(c,rt,info['team'],fixture['season'],info['roster'])
            rosters.add((info['team'],info['roster']['digest'],info['roster']['seen_at']))
            o._coverage_poll(c,rt,fixture,info,src,as_of,cache);teamchecks.append(info['team'])
        for ident in {i for fact in second['facts'] for i in (fact['id'],*fact.get('evidence_ids',[]))}:
            try: o._fact(c,rt,ident,fixture,as_of,cache,rosters)
            except ValueError as e: ctr[str(e)]+=1
        assert dict(ctr)=={'missing private retained response':10}
        assert not o.verify(c,rt,fixture,second)
    record['source_denominators']={'fixtures':len(docs),'players':len({f['player_id'] for f in facts}),'facts_by_source':dict(Counter(f['source'] for f in facts)),'polls_by_source_and_distinct_clubs':{s:[n,t] for s,n,t in receipts},'reopened_wiki_responses':[dict(decoded)[('wikipedia-season-news',when)] for when in ('initial','subsequent')],'wiki_original_sha_matches':len(licenses),'second_match_roster_and_source_verified':teamchecks,'second_match_reopen_errors':dict(ctr),'full_snapshot':False,'real_bound':v.report(rt)['bound_seals']}
    planning=cert['plan']['planning_power']
    for k,val in planning.items():
        if isinstance(val,list) and len(val)==108:
            record['a2_read_only']['power_cells']=108
    print(json.dumps(record,indent=2))
