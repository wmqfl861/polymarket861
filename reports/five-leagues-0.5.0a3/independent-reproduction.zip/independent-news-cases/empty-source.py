"""Full native pipeline with all facts public and one extra successful empty restricted feed."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json,os
from datetime import timedelta
from unittest.mock import patch
from polymarket861 import news, news_endpoint_preflight as pf, news_endpoint_v2 as v2, store
from test_news_endpoints_v2 import capture_clock
from test_paired_proof import at
from test_news_matchday import HOME,AWAY,HOME_OUT,AWAY_RUMOUR,KICKOFF,seed_fixture,add_club_feed,rss
from test_news_endpoint_study import collect_native_seal
work=Path(__file__).resolve().parent
with TemporaryDirectory(dir=work) as temp,capture_clock():
 root=Path(temp)/'store'
 hist=Path(temp)/'history'
 with at('2026-08-01T10:00Z'):
    seed_fixture(root,hist);v2.enroll(root)
    home,away=(add_club_feed(root,t) for t in (HOME,AWAY))
    extra=news.add_feed(root,home|{'id':'private-empty','url':'https://arsenal.example/no-news.xml','license':'Private personal use only'})
 kick=store.instant(KICKOFF)
 collect_native_seal(root,hist,{home['url']:rss(home,HOME_OUT),away['url']:rss(away,AWAY_RUMOUR),extra['url']:rss(extra)},kick-timedelta(minutes=95),kick-timedelta(minutes=61))
 with at(kick):
    r=pf.preflight(root);formal=v2.report(root)
    w,=r['windows']
    print(json.dumps({'news_evidence':w['news_evidence'],'applied_facts':w['applied_facts'],'facts':w['fact_dependencies'],'home':w['coverage']['home'],'known_blockers':w['known_blockers'],'official_exclusions':formal['horizons']['T-60m']['exclusions']},indent=2))
