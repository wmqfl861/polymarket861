from contextlib import closing
from collections import Counter
from pathlib import Path
import hashlib,json,sqlite3,shutil,socket,tempfile
from unittest.mock import patch
from polymarket861 import news_endpoint_preflight as p
from test_paired_proof import at
from test_news_endpoints_v2 import capture_clock
from test_news_matchday import KICKOFF
root=Path(__file__).resolve().parent
db_connect=sqlite3.connect
sqlwrites={getattr(sqlite3,expr) for expr in ('SQLITE_INSERT','SQLITE_UPDATE','SQLITE_DELETE','SQLITE_CREATE_TABLE','SQLITE_CREATE_VIEW','SQLITE_CREATE_TRIGGER','SQLITE_DROP_TABLE','SQLITE_ALTER_TABLE','SQLITE_CREATE_TEMP_TABLE','SQLITE_CREATE_TEMP_VIEW')}
issued=Counter(); opens=[]; net=[]
def restricted(dbpath,*args,**kwargs):
    c=db_connect(dbpath,*args,**kwargs)
    opens.append({'is_readonly_uri':'mode=ro' in str(dbpath),'file':Path(str(dbpath).split('?')[0]).name})
    def trace(act,a1,a2,db_name,other):
        if act in sqlwrites:
            issued[db_name or 'unknown']+=1
            if db_name=='main':
                return sqlite3.SQLITE_DENY
        return sqlite3.SQLITE_OK
    c.set_authorizer(trace)
    return c
def offline(*args,**kwargs):
    net.append(True);raise AssertionError('unexpected network')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(dir=root) as td:
    sub=Path(td)/'store';shutil.copytree(root.parent/'news-pref-native/registered/store',sub)
    dbfile=sub/'runtime.sqlite3'
    before=digest(dbfile)
    with capture_clock(),at(KICKOFF), patch.object(sqlite3,'connect',restricted),patch.object(socket.socket,'connect',offline),patch.object(socket,'getaddrinfo',offline):
        result=p.preflight(sub)
    assert before==digest(dbfile) and not net and not issued['main'] and all(x['is_readonly_uri'] for x in opens)
    assert result['news_evidence_counts']['bound_news_originals_verified']==1
    cold=Path(td)/'cold';cold.mkdir();dbfile=cold/'runtime.sqlite3'
    with closing(db_connect(dbfile)) as c:
        c.execute('pragma journal_mode=wal');c.execute('create table old_table(id)');c.commit()
    pristine=digest(dbfile); before_files={f.name:f.stat().st_size for f in cold.iterdir()}
    p.preflight(cold)
    print(json.dumps({'registered_case_readonly_sql_connections':opens,'sqlite_write_authorizations_requested_by_schema':dict(issued),'socket_or_DNS_calls':len(net),'main_database_bytes_identical':True,'cold_sqlite_wal_before':before_files,'cold_sqlite_wal_after':{f.name:f.stat().st_size for f in cold.iterdir()},'cold_main_db_content_identical':digest(dbfile)==pristine},indent=2))
