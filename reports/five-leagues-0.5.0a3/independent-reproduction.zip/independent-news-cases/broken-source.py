"""An unrelated broken local source descriptor should have unknown retention, not sink other windows."""
from pathlib import Path
import json,sqlite3,shutil,tempfile
from contextlib import closing
from polymarket861 import news_endpoint_preflight as pf
from test_news_endpoints_v2 import capture_clock
from test_news_matchday import KICKOFF
from test_paired_proof import at
work=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(dir=work) as tmp,at(KICKOFF),capture_clock():
 r=Path(tmp)/'data'
 shutil.copytree(work.parent/'news-pref-native/registered/store',r)
 with closing(sqlite3.connect(r/'runtime.sqlite3')) as db,db:
    updated=db.execute("update news_streams set config=json_set(config,'$.team',NULL) where source='wikipedia-season-news' and team_key='arsenal'")
    print('updated',updated.rowcount)
 try:
    d=pf.preflight(r)
    print(json.dumps({'fixed_windows':d['fixed_windows_total'],'unknown_builtin':[a for a in d['local_sources'] if a.get('raw_response_policy')=='unknown']},indent=2))
 except Exception as e:
    print(type(e).__name__,str(e))
