from copy import deepcopy
from datetime import timedelta
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from test_budget_domestic_archive import domestic_entry
from test_budget_research_fees import PROFILE, refresh
from paper_probes import replay
from polymarket861 import store

def late(flag):
    with TemporaryDirectory() as tmp:
        root=Path(tmp)
        doc,(main,aux)=domestic_entry(root,"sea",fee_schedule=PROFILE)
        op=doc["intents"][0];cut=store.instant(op["decision_at"]);received=cut+timedelta(hours=4)
        baseline=replay(root,doc,end=store.iso(received-timedelta(seconds=1)))
        late=deepcopy(aux);late.update(flag(cut,received))
        refresh(root,main,late,received)
        before=replay(root,doc,end=store.iso(received-timedelta(seconds=1)))
        visible=replay(root,doc,end=store.iso(received))
        assert baseline==before
        return [before["decisions"][0]["outcome"],visible["decisions"][0]["outcome"],visible["proof_gaps"]]
result={key:late(fn) for key,fn in (
    ("normally_final_was_still_after_execution", lambda t,r: {"ended":True,"gameStatus":"Final","finishedTimestamp":store.iso(r-timedelta(minutes=3))}),
    ("future_finish_metadata_cannot_backdate_a_game",lambda t,r:{"finishedTimestamp":store.iso(r+timedelta(hours=4))}),
    ("historical_finish_at_execution",lambda t,r:{"finishedTimestamp":store.iso(t+timedelta(seconds=5))}),
    ("historical_finish_before_execution",lambda t,r:{"finishedTimestamp":store.iso(t-timedelta(minutes=15))}),
    ("late_scoreboard_without_start_clock",lambda t,r:{"period":"FT","score":"2-1","elapsed":"90"}),
)}
assert [r[1] for r in result.values()]==["filled","filled","skipped_unverified_entry","skipped_unverified_entry","filled"]
print(json.dumps(result,indent=2))
