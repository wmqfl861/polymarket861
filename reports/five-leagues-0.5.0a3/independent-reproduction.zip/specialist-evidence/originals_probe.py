from collections import Counter, defaultdict
from contextlib import closing
from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
import sqlite3

from polymarket861 import budget_archive_proof as proof, store

SCRATCH = Path(__file__).resolve().parents[2]

def inspect(name):
    archive=SCRATCH/name/"five-league-market"
    physical_sha = sha256((archive/"runtime.sqlite3").read_bytes()).hexdigest()
    observations={}
    fee_profiles=Counter()
    flag_types=Counter()
    state_extras=Counter()
    interest=defaultdict(Counter)
    sample_by_league = {}
    with closing(sqlite3.connect((archive/"runtime.sqlite3").resolve().as_uri()+"?mode=ro",uri=True)) as db:
        for slug,stamp,d in db.execute("select slug,received_at,sha from ma_events order by received_at,slug"):
            body=store.read_blob(archive,d)
            assert sha256(body).hexdigest()==d
            raw=json.loads(body)
            found=[e for e in (raw if isinstance(raw,list) else [raw]) if e.get("slug")==slug]
            assert len(found)==1
            event=found[0]; key=(slug,stamp,d); observations[key]=event
            flag_types[(str(event.get("live")),str(event.get("ended")))]+=1
            state_extras[tuple(sorted(k for k in ("gameStatus","status","finishedTimestamp","period","elapsed","score") if event.get(k) is not None))]+=1
            for m in event.get("markets",[]):
                profile=store.canonical(m.get("feeSchedule"))
                for field in ("feeType","makerBaseFee","takerBaseFee","feesEnabled"):
                    interest[field][str(m.get(field))]+=1
                fee_profiles[profile]+=1
        latest={}
        for slug,stamp,d,payload in db.execute("select event_slug,received_at,sha,payload from ma_contracts order by received_at"):
            market=json.loads(payload)
            if market.get("mapping_error") or market["family"] not in {"moneyline","total","home_total","away_total"}:continue
            seen=observations[slug,stamp,d]
            native=[m for m in seen["markets"] if m.get("conditionId")==market['condition_id']]
            assert len(native)==1 and native[0]["feeSchedule"]==market["fee_schedule"] and native[0]["feesEnabled"] is True
            latest[market["condition_id"]]=(slug,stamp,d,market)
        checks = Counter()
        for condition,(slug,stamp,d,market) in latest.items():
            lg=slug.split("-")[0]
            checks[lg]+=1
            sample_by_league.setdefault(lg,(condition,stamp,market["tokens"][0]["token_id"],d))
        book_times=defaultdict(set)
        book_rows=0
        for token,stamp in db.execute("select token,received_at from ma_books order by received_at"):
            book_rows+=1;book_times[token].add(datetime.fromisoformat(stamp))
        gaps=[(b-a).total_seconds() for ts in book_times.values() for a,b in zip(sorted(ts),sorted(ts)[1:])]
    sample_terms={}
    for lg,(condition,stamp,token,d) in sample_by_league.items():
        result=proof.verify_contract(archive,condition,stamp,token=token,scheduled=True)
        try: proof.verify_contract(archive,condition,stamp,token=token)
        except ValueError as exc: strict=str(exc)
        else: strict="allowed"
        assert result["source_sha256"]==d and result["fee_basis"]=="research_assumption" and strict!="allowed"
        sample_terms[lg]={"basis":result["fee_basis"],"sha":d,"strict":strict,"books":result["order_books_checked"]}
    assert sha256((archive/"runtime.sqlite3").read_bytes()).hexdigest()==physical_sha
    return {"original_event_receipts":len(observations),"events_by_live_and_ended":{str(k):v for k,v in flag_types.items()},
        "extra_event_states":{str(k):v for k,v in state_extras.items()},"eligible_distinct_conditions":len(latest),
        "leagues":dict(checks),"fee_profile_all_raw_rows":dict(fee_profiles),"raw_fee_fields_all_rows":{k:dict(v) for k,v in interest.items()},
        "books":book_rows,"distinct_book_tokens":len(book_times),"differences":len(gaps),"minimum_gap_seconds":min(gaps,default=None),
        "5_to_40_gaps":sum(5<=x<=40 for x in gaps),"sample_terms":sample_terms,"db_sha256":physical_sha}
print(json.dumps({name:inspect(name) for name in ("pm861-v05-market-archive-final","review05a2/live")},ensure_ascii=False,indent=2))
