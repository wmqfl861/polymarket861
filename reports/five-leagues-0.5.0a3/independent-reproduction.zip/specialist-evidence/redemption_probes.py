from contextlib import closing
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import json,sqlite3
import test_capital_native_proof as fx
from test_budget_research_fees import PROFILE
from test_budget_domestic_archive import domestic_entry
from paper_probes import authority,replay
from polymarket861 import big5_market,budget_archive_proof,fee_registry,ledger_terms,store

def split(market_type):
    native=fx.receive
    with TemporaryDirectory() as tmp:
        root=Path(tmp)
        def record(root,event,stamp):
            event=deepcopy(event)
            event["markets"][0].update(feesEnabled=True,feeSchedule=PROFILE)
            event.pop("live",None);event.pop("ended",None)
            return native(root,event,stamp)
        def intent(root,condition,token,now):
            e=budget_archive_proof.verify_contract(root,condition,now,token=token,scheduled=True)["intent_terms"]
            return e["selection"]|{"rule_sha256":e["rule_sha256"],"fee_schedule":e["fee"]}
        # Only build the submitted intention via the public terms export. Its subsequent replay is unpatched.
        with patch.object(fx,"receive",record),patch.object(ledger_terms,"contract_at",intent):
            doc,market=fx.received_entry(root,market_type=market_type)
        op=doc["intents"][0];at=store.iso(store.instant(op["kickoff"])+timedelta(hours=4))
        for i in range(2):
            row=fx.terminal_row(market,i,.5)
            sha=fx.record_terminal(root,row["token_id"],json.dumps({"data":[row]}).encode(),at)
            if i==0: doc["redemptions"]=[{"id":"pair","at":at,"original_sha256":sha}|{k:op[k] for k in ('fixture_id','condition_id','token_id')}]
        out=replay(root,doc)
        return {"assessed":out["proof_gaps"],"outcome":out["leagues"]["epl"]["outcomes"],"balances":out["leagues"]["epl"]["settled_paper_pnl_by_fee_basis"]["research_assumption"]}
def authority_gaps(kind):
    with TemporaryDirectory() as tmp:
        root=Path(tmp)
        doc,_=domestic_entry(root,"sea",fee_schedule=PROFILE)
        op=doc["intents"][0];at=op["decision_at"]
        p=authority(root)
        policies=(p,replace(p,key="sibling")) if kind=="ambiguous" else (p,)
        with patch.object(fee_registry,"REVIEWED",policies):
            archive=big5_market.research_root(root)
            if kind=="missing_request":
                with closing(sqlite3.connect(archive/'runtime.sqlite3')) as db,db:
                    db.execute("delete from ma_requests where operation='fee_policy'")
            if kind=="corrupt_bytes":
                store.blob_path(archive,p.documents[0].sha256).write_bytes(b"modified evidence")
            try: value=budget_archive_proof.verify_contract(root,op["condition_id"],at,token=op["token_id"],scheduled=True)
            except ValueError as exc: value=str(exc)
            out=replay(root,doc)
            return {"export_error":value,"outcome":out["decisions"][0]["outcome"],"funds":out["leagues"]["sea"]["available_cash"]}
if __name__=="__main__":
    print(json.dumps({"split":{m:split(m) for m in ("total","home_total","moneyline")},
        "authority":{k:authority_gaps(k) for k in ("missing_request","corrupt_bytes","ambiguous")}},indent=2))
