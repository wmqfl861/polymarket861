import json
from pathlib import Path
from tempfile import TemporaryDirectory
from datetime import timedelta
from copy import deepcopy
from unittest.mock import patch
from polymarket861 import five_league_budget as budget,store
import test_budget_domestic_archive as fx
from test_budget_research_fees import PROFILE,refresh
from test_budget_scheduled_entry import BASIS
from paper_probes import authority

raw=fx.native
def native(*args,**kw):
    event=raw(*args,**kw)
    for m in event["markets"]:
        m.update(feeType="sports_fees_v3",takerBaseFee=1000,makerBaseFee=1000)
    return event

def test(kind,field,change):
    with TemporaryDirectory() as tmp,patch.object(fx,"native",native):
        root=Path(tmp)
        reviewed=(authority(root),) if kind=="authority" else ()
        with patch("polymarket861.fee_registry.REVIEWED",reviewed):
            doc,(main,aux)=fx.domestic_entry(root,"bun",explicit=True,fee_schedule=PROFILE)
            op=doc["intents"][0];when=store.instant(op["decision_at"])
            altered=deepcopy(main)
            if change is None: altered["markets"][0].pop(field)
            else: altered["markets"][0][field]=change
            refresh(root,altered,aux,when+timedelta(seconds=1))
            refresh(root,main,aux,when+timedelta(seconds=3))
            result=budget.replay(doc,data_dir=root,entry_basis=BASIS,details=True)
            return [result["decisions"][0]["outcome"],result["proof_gaps"]]
if __name__=="__main__":
    print(json.dumps({kind:{f"{f}:{v}":test(kind,f,v) for f,v in (("feeType","sports_fees_v3"),("feeType","sports_fees_v4"),("feeType",None),("takerBaseFee",2500),("makerBaseFee",1001),("takerBaseFee","1000"))} for kind in ("estimate","authority")},indent=2))
