import json, os, sys
from contextlib import closing
from pathlib import Path
from tempfile import TemporaryDirectory
import subprocess

here=Path(__file__).resolve()
scratch=here.parents[2]
a2=scratch/"review05a3"/"before"; a3=Path(os.environ.get("PM861_AUDIT_REPO", scratch/"review05a3"/"frozen"))
if len(sys.argv)>1:
    import test_big5_receipt_grades as helpers
    from polymarket861 import big5_market as big5
    mode=sys.argv[1]; base=Path(sys.argv[2])
    evidence={}
    for label,state in [
        ("prior_aux_second_half",{"period":"2H","score":"0-0","elapsed":"45:01"}),
        ("prior_main_finished",{"finishedTimestamp":helpers.store.iso(helpers.CUTOFF-helpers.timedelta(minutes=35))}),
        ("prior_aux_official_status",{"gameStatus":"InProgress"}),
        ("pregame_zero",{"period":"NS","score":"0-0","elapsed":"0"}),
    ]:
        c=helpers.TestDomesticReceiptGrades()
        c.base=base/label
        if mode=="make":
            c._leg(-20,state if label=="prior_main_finished" else {}, {} if label=="prior_main_finished" else state,watch=False)
            c._leg(-10,{},{})
            c._leg(6,{},{})
        r=c._counts()
        with closing(big5._db(big5.research_root(c.base))) as db:
            versions=[v[0] for v in db.execute("select version from big5_schedule_recovery order by version")]
            raw=db.execute("select count(*) from ma_books").fetchone()[0]
        evidence[label]={k:r.get(k,0) for k in ("fixed_windows_complete","fixed_windows_not_pregame","t1_pairs_schedule_only","t1_pairs_not_pregame","t1_pairs_explicit_pregame")}
        evidence[label].update(versions=versions,raw_books=raw)
    print(json.dumps(evidence))
else:
    with TemporaryDirectory() as tmp:
        runs={}
        for name,repo,op in (("a2_wrote",a2,"make"),("a3_reopened",a3,"read"),("repeat_a3",a3,"read")):
            p=subprocess.run([sys.executable,str(here),op,tmp],check=True,capture_output=True,cwd=here.parent,
                env=os.environ|{"PYTHONPATH":os.pathsep.join(map(str,(repo/"src",repo/"tests"))),"PYTHONDONTWRITEBYTECODE":"1"})
            runs[name]=json.loads(p.stdout)
        assert runs["a3_reopened"]==runs["repeat_a3"]
        for label in runs["a2_wrote"]:
            assert runs["a2_wrote"][label]["raw_books"]==runs["a3_reopened"][label]["raw_books"]==28
        print(json.dumps(runs,indent=2))
