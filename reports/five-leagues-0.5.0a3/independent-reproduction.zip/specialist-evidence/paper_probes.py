from collections import Counter
from contextlib import closing
from copy import deepcopy
from datetime import timedelta
from decimal import Decimal as D, ROUND_CEILING, ROUND_DOWN
from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import test_budget_domestic_archive as fixture
from test_budget_research_fees import PROFILE, refresh
from test_budget_scheduled_entry import BASIS
from test_capital_native_proof import record_terminal, terminal_row
from polymarket861 import big5_market, big5_market_schedule, budget_archive_proof, fee_registry, five_league_budget, market_archive, market_provider, store

def replay(root, doc, end=None):
    return five_league_budget.replay(doc, data_dir=root, as_of=end, entry_basis=BASIS, details=True)

def authority(root, recv="2030-01-12T10:00:00Z", until="2030-01-14T00:00:00Z"):
    policy_doc = b"Specialist fee-source fixture in a scratch account only."
    digest = sha256(policy_doc).hexdigest()
    date = "2030-01-10T00:00:00.000000Z"
    doc = fee_registry.Document("https://docs.polymarket.com/specialist-local-fixture", digest, date)
    policy = fee_registry.FeePolicy("specialist-fixture", "v1", ("moneyline",), date, store.iso(until), (doc,),
        "0.05", 1, "symmetric", "shares", "eip155:137/erc20:0x" + "a"*40,
        "cash", "0.00001", "half_up", "per_execution_price_level", "ceil_at_0.000001_shares")
    receipt = market_provider.Reply(policy_doc, store.iso(recv), store.iso(recv), {}, doc.url)
    with patch.object(fee_registry, "REVIEWED", (policy,)), patch.object(fee_registry,"_read_document", return_value=receipt):
        fee_registry.capture(big5_market.research_root(root), policy.key)
    return policy

def schedule_cases():
    raw = fixture.native
    cases = {
        "plain": {}, "past_finished": {"finishedTimestamp":"2030-01-12T12:30:00Z"},
        "second_half": {"period":"2H","elapsed":"67","score":"2-1"},
        "pregame_zero": {"period":"NS","elapsed":"0","score":"0-0"},
        "status_FT": {"gameStatus":"FT"}, "status_PRE": {"gameStatus":"PRE"},
        "archived_parent": {"archived":True}, "unknown_period": {"period":"tbd-or-retired-provider-code"},
    }
    out = {}
    for label, gamma in cases.items():
        for explicit in (True,False):
            def native(*a, **kw): return raw(*a, **kw) | gamma
            with TemporaryDirectory() as name, patch.object(fixture,"native",native):
                root = Path(name)
                doc, (main, aux) = fixture.domestic_entry(root,"bun",explicit=explicit,fee_schedule=PROFILE)
                r = replay(root, doc)
                out[label + ("_explicit" if explicit else "_absent")] = [big5_market_schedule.pregame_flags(main, store.instant(doc["intents"][0]["decision_at"]) - timedelta(minutes=3)),
                    r["decisions"][0]["outcome"],r["proof_gaps"]]
    return out

def authority_cases():
    output = {}
    for name, schedule, recv, until in [
        ("matching_clean", PROFILE,"2030-01-12T10:00:00Z","2030-01-14T00:00:00Z"),
        ("unknown_charge", PROFILE | {"additionalCashPerShare":0.03},"2030-01-12T10:00:00Z","2030-01-14T00:00:00Z"),
        ("wrong_gamma_rate", PROFILE | {"rate":0.07},"2030-01-12T10:00:00Z","2030-01-14T00:00:00Z"),
        ("nonsensical_rebate",PROFILE | {"rebateRate":-1},"2030-01-12T10:00:00Z","2030-01-14T00:00:00Z"),
        ("unknown_taker",PROFILE | {"takerOnly":None},"2030-01-12T10:00:00Z","2030-01-14T00:00:00Z"),
        ("arrives_between_book_and_decision", PROFILE,"2030-01-12T12:59:59.500000Z","2030-01-14T00:00:00Z"),
        ("expires_at_execution",PROFILE,"2030-01-12T10:00:00Z","2030-01-12T13:00:05Z"),
        ("already_expired",PROFILE,"2030-01-12T10:00:00Z","2030-01-12T12:59:59Z"),
    ]:
        with TemporaryDirectory() as tmp:
            root=Path(tmp)
            p=authority(root,recv,until)
            try:
                with patch.object(fee_registry,"REVIEWED",(p,)):
                    doc, _=fixture.domestic_entry(root,"sea",explicit=True,fee_schedule=schedule)
                    r=replay(root,doc)
                    decision=r["decisions"][0]
                    output[name]=[decision['outcome'], (decision["fee_evidence"] or {}).get("basis"),r["proof_gaps"]]
            except ValueError as exc:
                output[name]=["refused_terms",str(exc)]
    return output

def calculations(outcome):
    with TemporaryDirectory() as tmp:
        root=Path(tmp)
        books = {
            "a": [{"price":"0.52","size":"19"},{"price":"0.62","size":"30"}],
            "b": [{"price":"0.51","size":"9"},{"price":"0.52","size":"13"},{"price":"0.61","size":"30"}],
        }
        doc,(event,_)=fixture.domestic_entry(root,"lal",fee_schedule=PROFILE,asks=books)
        op=doc["intents"][0]
        op.update(shares="40",limit_price="0.62")
        # p=.52 for 19 shares, then .62 for 21, grouping two shared half-price segments.
        prices=[(D(".52"),D(19)),(D(".62"),D(21))]
        cash=sum(p*q for p,q in prices)
        fee_by_level=[(((p*(1-p)*D(".05")*q).quantize(D(".01"),rounding=ROUND_CEILING))/p)
                       .quantize(D(".000001"),rounding=ROUND_CEILING) for p,q in prices]
        net=D(40)-sum(fee_by_level)
        doc["intents"].append(dict(op, id="retry-different-name",rank=2))
        market=market_archive.contracts(big5_market.research_root(root),event["slug"],as_of=op["decision_at"])[0]
        time=store.instant(op["kickoff"])+timedelta(hours=4)
        terminal=terminal_row(market,0,outcome)
        opposite=terminal_row(market,1,1-outcome)
        archive=big5_market.research_root(root)
        held=record_terminal(archive,terminal["token_id"],json.dumps({"data":[terminal]}).encode(),store.iso(time))
        doc["redemptions"]=[dict(id="redeem",at=store.iso(time),original_sha256=held,
            **{k:op[k] for k in ('condition_id','fixture_id','token_id')})]
        unverified=replay(root,doc)
        when=store.iso(time+timedelta(seconds=1))
        record_terminal(archive,opposite["token_id"],json.dumps({"data":[opposite]}).encode(),when)
        doc["redemptions"].append(dict(doc["redemptions"][0],id="retry-redeem",at=when))
        old=replay(root,doc,store.iso(time))
        final=replay(root,doc,when)
        fill=final["decisions"][0]["fill"]
        acc=final["leagues"]["lal"]["settled_paper_pnl_by_fee_basis"]["research_assumption"]
        observed=D(acc["cash_from_redemptions"]); payout=(net*D(outcome)).quantize(D(".000001"),rounding=ROUND_DOWN)
        assert D(acc["buy_cash"])==cash and D(fill["net_shares"])==net and observed==payout
        assert all(D(x["fee_shares"])==expected for x,expected in zip(fill["levels"],fee_by_level))
        assert D(old["leagues"]["lal"]["unredeemed_cost"])==D(unverified["leagues"]["lal"]["unredeemed_cost"])==cash
        assert D(acc["settled_paper_pnl"])==payout-cash and D(final["leagues"]["lal"]["available_cash"])==D(2000)+payout-cash
        return {"grouped_price_levels":fill["levels"],"net":str(net),"cash":str(cash),"credit":str(observed),
                "independent_expected_pnl":str(payout-cash),"by_fee":acc,"reasons":final["leagues"]["lal"]["outcomes"],
                "older_cutoff_still_locked":old["leagues"]["lal"]["unredeemed_cost"],"venue_pnl":final["venue_realized_pnl"]}

if __name__ == "__main__":
    print(json.dumps({"fee_ledger_win":calculations(1),"fee_ledger_loss":calculations(0),
        "gamma":schedule_cases(),"authoritative":authority_cases()},ensure_ascii=False,indent=2))
