from collections import Counter
from contextlib import closing
import json
from hashlib import sha256
from pathlib import Path
import sqlite3
from polymarket861 import news, news_endpoint_originals, news_endpoint_v2, news_endpoint_preflight,store

base=Path(__file__).resolve().parents[2]
inputs=base/"review05a3/news-sources"
runtime=inputs/"state"
import os
rp=Path(os.environ.get("PM861_AUDIT_REPO", base/"review05a3"/"frozen"))/"reports/five-leagues-0.5.0a3/news-source-readiness.json"
published=json.loads(rp.read_bytes())
def db_digest(): return sha256((runtime/"runtime.sqlite3").read_bytes()).hexdigest()
db_before=db_digest()
src=Counter();players=set();events=Counter();statuses=Counter();total=0
for f in sorted(inputs.glob("facts-*.json")):
    previous=json.loads(f.read_bytes())
    again=news.snapshot(runtime,previous["fixture_id"],previous["cutoff"])
    assert again==previous
    for fact in again["facts"]:
        total+=1;players.add(str(fact["player_id"]))
        src[fact["source"]]+=1;events[fact["event"]]+=1;statuses[fact["status"]]+=1
with closing(sqlite3.connect((runtime/"runtime.sqlite3").resolve().as_uri()+"?mode=ro",uri=True)) as db:
    db.row_factory=sqlite3.Row
    db.execute("begin")
    reg=news_endpoint_v2._registration(db)
    news_endpoint_originals.scope_originals(db,news_endpoint_originals.V2_ORIGINALS,reg["registration_sha256"])
    native_by_src=Counter();clubs=set()
    cutoff=published["initial_cli_collection"]["fixture_snapshot_read_interval"][-1]
    for row in db.execute("select * from news_endpoint_poll_originals where observed_at<=? order by observed_at",(cutoff,)):
        cfg=json.loads(row["document"])["config"]
        p,parsed,verified_cfg=news_endpoint_originals._verified_poll(db,runtime,row["receipt"],row["season"],cfg["team"],row["source"],cutoff,{})
        assert sha256(store.read_blob(runtime,p["response_sha256"])).hexdigest()==p["response_sha256"]
        clubs.add(row["club"]);native_by_src[row["source"]]+=1
    frozen=news_endpoint_preflight.preflight(runtime)
    assert frozen["fixed_windows_checked"]==0 and frozen["future_eligible_windows"] is None
assert total==published["initial_cli_collection"]["news_facts_total"]
assert len(players)==published["initial_cli_collection"]["distinct_resolved_player_ids"]
assert statuses==published["initial_cli_collection"]["facts_by_status"] and events==published["initial_cli_collection"]["facts_by_event"]
assert db_before==db_digest()
print(json.dumps(dict(local_fixtures_reopened=10,atomic_snapshots_equal=10,by_source=dict(src),by_status=dict(statuses),by_event=dict(events),unique_players=len(players),v2_retained_verified=dict(native_by_src),clubs_with_verified_originals=len(clubs),fixed_windows=frozen["fixed_windows_checked"],future_eligible=frozen["future_eligible_windows"],scratch_database_unchanged=True),indent=2))
