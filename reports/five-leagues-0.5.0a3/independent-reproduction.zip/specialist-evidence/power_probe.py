from pathlib import Path
import json
import numpy as np
from scipy.stats import t
import os
root=Path(os.environ.get("PM861_AUDIT_REPO", Path(__file__).resolve().parents[1]/"frozen"))/"reports"
observed=json.loads((root/"news-early-seals-0.4.2.json").read_bytes())["technical_early_seals"]
design=json.loads((root/"five-leagues-0.5.0a2/news-endpoint-power-v2.json").read_bytes())
seed, rounds, per, draws = 118034, 65, 10, 5000
rng=np.random.default_rng(seed)
crit=float(t.ppf(1-0.05/(2*14),rounds-1))
out=[]
for native,endpoint in (("home_win","home_win"),("total_over_2_5","full_over_2_5")):
    delta=np.array([x["arms"]["with_news"]["probabilities"][native]-x["arms"]["no_news"]["probabilities"][native] for x in observed])
    for blocks,layout in [(1,'one_mode_era'),(4,'four_mode_era_groups')]:
        hits=total=0
        for _ in range(draws//200):
            x=rng.choice(delta,(200,rounds,per));y=.5*x+.05*(np.sqrt(.05)*rng.normal(size=(200,rounds,1))+np.sqrt(.95)*rng.normal(size=x.shape))
            for start,end in zip(np.rint(np.linspace(0,rounds,blocks+1)).astype(int),np.rint(np.linspace(0,rounds,blocks+1)).astype(int)[1:]):
                for z in (x,y):
                    z[:,start:end,:]-=z[:,start:end,:].mean(axis=(1,2),keepdims=True)
            xsq=(x*x).sum(axis=(1,2))
            slope=(x*y).sum(axis=(1,2))/xsq
            u=y-slope[:,None,None]*x
            score=(u*x).sum(axis=2)
            se=(score**2).sum(axis=1)**.5/xsq*np.sqrt(rounds/(rounds-1)*(rounds*per-1)/(rounds*per-blocks-1))
            hits+=np.sum(slope-crit*se>0)
            total+=len(slope)
        published=next(row for row in design['cells'] if row['endpoint']==endpoint and row['layout']==layout and row['rounds']==rounds and row['matches']==rounds*per and row['assumed_gap_sd_pp']==5 and row['assumed_slope']==.5)['lower_bound_above_zero']
        ours=float(hits/total)
        pooled=(ours*(1-ours)/total + published*(1-published)/design['replications_per_cell'])**.5
        out.append(dict(endpoint=endpoint,strata=blocks,published=published,independent=ours,difference_in_joint_MCSE=round((ours-published)/pooled,3)))
print(json.dumps(dict(independent_seed=seed,draws_per_cell=draws,family=14,critical_t=crit,results=out),indent=2))
