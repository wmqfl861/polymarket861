from contextlib import closing
from copy import deepcopy
from datetime import timedelta
from hashlib import sha256
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

from polymarket861 import news, news_endpoint_preflight as check, news_endpoint_v2 as v2, news_model, store
from test_news_endpoint_preflight import EndpointPreflight
from test_news_endpoint_study import raw_seal
from test_news_endpoints_v2 import capture_clock
from test_news_matchday import KICKOFF
from test_paired_proof import at

BASE=Path(__file__).resolve().parents[2]
REPO=Path(os.environ.get("PM861_AUDIT_REPO", BASE/"review05a3"/"frozen"))
BEFORE=BASE/"review05a3"/"before"

def call(repo,root,action,version="v2"):
    args=[sys.executable,"-m","polymarket861","--data-dir",str(root),"leagues","news-endpoints",action,"--version",version]
    return subprocess.run(args, capture_output=True, env=os.environ | {"PYTHONPATH":str(repo/"src"),"PYTHONDONTWRITEBYTECODE":"1"},
                          check=False,cwd=root.parent)

def bundle(root):
    return {f.name:sha256(f.read_bytes()).hexdigest() for f in root.glob("*.sqlite3")}

def read_json(result):
    assert result.returncode==0, result.stderr
    return json.loads(result.stdout)

def cross_version():
    with TemporaryDirectory() as tmp:
        root=Path(tmp)/"controlled-only"
        v1=read_json(call(BEFORE,root,"register","v1"))
        registered=read_json(call(BEFORE,root,"register"))
        a2=read_json(call(BEFORE,root,"report"))
        initial=bundle(root)
        a3=read_json(call(REPO,root,"report"))
        repeat=read_json(call(REPO,root,"register"))
        pref=read_json(call(REPO,root,"preflight"))
        compat=read_json(call(REPO,root,"report","v1"))
        assert a2==a3 and registered==repeat==a3["registration"]
        assert v1==compat["registration"]
        assert pref["registration"]["registration_sha256"]==registered["registration_sha256"]
        assert bundle(root)==initial
        published=json.loads((REPO/"reports/five-leagues-0.5.0a2/news-endpoint-study-v2.json").read_bytes())
        original=store.canonical(published["plan"]).encode()
        result={"copied_baseline_digest":sha256(original).hexdigest(),"a2_a3_reports_equal":a2==a3,
            "v2_certificate":registered["registration_sha256"],"same_v1_certificate":v1==compat["registration"],
            "db_bytes_unchanged":True, "registered_end":registered["ends_at"],"computations":registered["plan"]["family_comparisons"]}
        def changed_proposal():
            plan=deepcopy(published["plan"])
            plan["reporting"]+= " "
            return {"plan":plan,"plan_sha256":store.digest(plan)}
        with patch.object(v2,"proposal",side_effect=changed_proposal):
            errors={}
            for name,fn in (("preflight",check.preflight),("report",v2.report),("repeat registration",v2.enroll)):
                try: fn(root)
                except ValueError as exc: errors[name]=str(exc)
            assert len(errors)==3
            result["runtime_drift_errors"]=errors
        return result

def future_and_originals():
    case=EndpointPreflight()
    case.setUp()
    try:
        with capture_clock(),at(KICKOFF):
            case._native(register=True)
            root=case.root
            baseline=check.preflight(root)
            win=baseline["windows"][0]
            assert win["news_evidence"]=="bound_news_originals_verified"
            cutoff=store.instant(win["sealed_at"])
            old_now=cutoff+timedelta(seconds=2)
            with at(old_now):
                before=check.preflight(root)
                report_before=v2.report(root)
            with closing(store.connect(root)) as db:
                cfg=json.loads(db.execute("select config from news_feed_config order by id limit 1").fetchone()[0])
            then=store.instant(KICKOFF)+timedelta(days=30)
            with at(then):
                news.add_feed(root,cfg | {"id":"future-source-canary","url":"https://arsenal.example/future-canary.xml"})
                news.disable_feed(root,cfg["id"])
                with closing(store.connect(root)) as db,db:
                    raw_seal(db,"epl/2026-27/future-probe/canary",then)
            with at(old_now):
                after=check.preflight(root); report_after=v2.report(root)
                assert before==after and report_before==report_after
            with at(then+timedelta(days=2)):
                new=check.preflight(root)
            assert "future-source-canary" in {r["source"] for r in new["local_sources"]}
            assert new["fixed_windows_total"]==baseline["fixed_windows_total"]+1
            # Make a once-valid receipt physically recorded later, self-consistent across envelope/index.
            # Leave the same timestamped v1 raw bytes in place to rule out accidental v1 substitution.
            with closing(store.connect(root)) as db,db:
                row=db.execute("select * from news_endpoint_v2_poll_originals where source='arsenal-bulletins' limit 1").fetchone()
                doc=json.loads(row["document"]);oldmeta=store.canonical(doc["metadata"])
                doc["metadata"]["recorded_at"]=store.iso(then)
                with db:
                    db.execute("update news_endpoint_v2_poll_originals set document=?,digest=? where receipt=?",
                               (store.canonical(doc),store.digest(doc),row["receipt"]))
                    db.execute("update observations set metadata=? where sha256=? and metadata=?",
                               (store.canonical(doc["metadata"]),row["response_sha"],oldmeta))
                v1_count=db.execute("select count(*) from news_endpoint_poll_originals where receipt=?",(row["receipt"],)).fetchone()[0]
            with at(old_now):
                altered=check.preflight(root)["windows"][0]
            assert altered["news_evidence"]=="expected_ineligible" and v1_count==1
            assert "missing_or_invalid_v2_original" in altered["known_blockers"]
            with at("2026-07-01T12:00Z"):
                pre_registration_clock=check.preflight(root)
            return {"valid_native":{"fixed_windows":baseline["fixed_windows_total"],
                "classification":win["news_evidence"],"timely_both":win["timely_two_team_coverage"],
                "facts":{r["source"]:r["v2_original"] for r in win['fact_dependencies']}},
                "earlier_preflight_equal_after_future_seal_config_and_disable":before==after,
                "earlier_report_equal_after_future_seal_config_and_disable":report_before==report_after,
                "later_windows":new["fixed_windows_total"],"later_feed_visible":True,
                "future_receipt_despite_v1":{"state":altered["news_evidence"],"blockers":altered["known_blockers"],
                   "v1_present":v1_count,"sources":{r["source"]:r["v2_original"] for r in altered["fact_dependencies"]}},
                "before_database_registration_clock":{"bound_windows":pre_registration_clock["fixed_windows_checked"],
                    "state":pre_registration_clock["registration"]["state"],"future_eligibility":pre_registration_clock["future_eligible_windows"]}}
    finally:
        case.doCleanups()

if __name__=="__main__":
    print(json.dumps({"compatibility":cross_version(),"chronology":future_and_originals()},ensure_ascii=False,indent=2))
