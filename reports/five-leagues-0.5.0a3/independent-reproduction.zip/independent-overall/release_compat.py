"""Measure 1,900 B1 matches independently and reopen a saved, approved a2 instance copy."""
from contextlib import closing
import hashlib, json, shutil, sqlite3, sys
from pathlib import Path
from tempfile import TemporaryDirectory
from polymarket861 import football,model_study,pipeline,store
import polymarket861

source=Path(sys.argv[1]);history=Path(sys.argv[2])
with TemporaryDirectory() as work:
    root=Path(work)/'copy'; shutil.copytree(source,root,ignore=shutil.ignore_patterns('runtime.sqlite3*'))
    with closing(sqlite3.connect((source/'runtime.sqlite3').resolve().as_uri()+'?mode=ro',uri=True)) as old,closing(sqlite3.connect(root/'runtime.sqlite3')) as new:
        old.backup(new)
    with closing(store.connect(root)) as db:
        seal=db.execute("SELECT * FROM forecast_seals ORDER BY rowid DESC LIMIT 1").fetchone()
        saved=pipeline._verified_seal(seal)
    p=store.digest(pipeline._build_recipe('B1',football.DEFAULT_LINES))
    with closing(store.connect(root)) as db:
        latest=db.execute("SELECT version FROM builtin_model_releases ORDER BY id DESC LIMIT 1").fetchone()[0]
    identity=pipeline.register_recipe(root,'B1@'+p,'B1')
    audit=model_study.measure(root,'B1@'+p,history,model_study.BENCHMARK)
    with closing(model_study._db(root)) as db:
        result=model_study._read(root,db,p,model_study.BENCHMARK)
        rows=result['rows']; rounds={(r[1],r[2]) for r in rows}
        summary={'release':polymarket861.__version__,'active_version_from_a2_copy':latest,'recipe':p,'matches':len(rows),'rounds':len(rounds),
                 'probabilities_sha256':store.digest([[r[0],r[6],r[7]] for r in rows]),'training_views_sha256':store.digest([[r[0],r[5]] for r in rows]),
                 'old_seal_sha256':seal['digest'],'reopened_seal_payload_sha256':hashlib.sha256(store.canonical(saved).encode()).hexdigest(),
                 'numeric_runtime':model_study.numeric_runtime(),'executed_physical_provenance_sha256':identity['release_provenance_sha256']}
    print(json.dumps(summary,indent=2))
