"""Rebuild buying fees and net terminal redemptions with an independent Decimal oracle."""
import hashlib
import json
from contextlib import ExitStack
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta
from decimal import Decimal as D, ROUND_CEILING, ROUND_HALF_UP, ROUND_DOWN
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from polymarket861 import (big5_market as collector,budget_archive_proof as proof,fee_registry as reg,
                            five_league_budget as budget,market_archive,market_provider as provider,store)
from test_budget_domestic_archive import domestic_entry
from test_capital_native_proof import record_terminal,terminal_row

research='scheduled_with_incomplete_flags'
gamma={'rate':0.05,'exponent':2,'takerOnly':True,'rebateRate':0.15}
cu=D('0.000001')
shares=[D('8.5'),D('16.625')]
prices=[D('.50'),D('.52')]


def charge_oracle(asset,round_in,quantum,method):
    q=D(quantum)
    costs=[]; token=[]; levels=[]
    for lots,p in zip(shares,prices):
        unrounded=lots*D('.05')*(p*(1-p))**2
        raw=unrounded/p if round_in=='charged' else unrounded
        bill=(raw/q).to_integral_value(rounding=method)*q
        cost=bill if asset=='cash' else D(0)
        paid=(bill/p).quantize(cu,rounding=ROUND_CEILING) if (asset,round_in)==('shares','cash') else bill if asset=='shares' else D(0)
        costs.append(cost);token.append(paid);levels.append([p,lots,cost,paid])
    notional=sum(n*p for n,p in zip(shares,prices))
    return levels,(notional+sum(costs)).quantize(cu,rounding=ROUND_CEILING),sum(shares)-sum(token)


def test(case, asset='shares', round_in='cash', quantum='.01', method='up', more=None):
    profile=dict(gamma)
    original_profile=deepcopy(profile)
    asks={k:[{'price':'.50','size':'8.5'},{'price':'.52','size':'80'}] for k in 'ab'}
    with TemporaryDirectory() as folder, ExitStack() as ctl:
        data=Path(folder); root=collector.research_root(data)
        if more:
            # The fixture's setup normally asks for an estimated intent. The probe
            # exports the actual intent below after the synthetic authority exists.
            dummy={'intent_terms': {'fee': {'enabled': False},'rule_sha256': '0'*64,'selection': {}}}
            with patch.object(proof,'verify_contract',return_value=dummy):
                doc,(main,aux)=domestic_entry(data,'sea',explicit=True,fee_schedule=profile | more,asks=asks)
        else:
            doc,(main,aux)=domestic_entry(data,'sea',explicit=True,fee_schedule=profile,asks=asks)
        op=doc['intents'][0]; op.update(limit_price='0.52',shares='25.125')
        at=store.instant(op['decision_at']); raw=b'local synthetic authority receipt for independent arithmetic'
        received=store.iso(at-timedelta(hours=1)); original=reg.Document('https://docs.polymarket.com/test-only/audit-fee',hashlib.sha256(raw).hexdigest(),store.iso(at-timedelta(days=2)))
        policy=reg.FeePolicy('audit-only','v1',('moneyline',),original.published_at,store.iso(at+timedelta(days=1)),(original,),'0.05',2,'symmetric',asset,'eip155:137/erc20:0x'+'a'*40,round_in,quantum,method,'per_execution_price_level','ceil_at_0.000001_shares' if (asset,round_in)==('shares','cash') else 'none')
        if case!='estimate':
            ctl.enter_context(patch.object(reg,'REVIEWED',(policy,)))
            ctl.enter_context(patch.object(reg,'_read_document',return_value=provider.Reply(raw,received,received,{},original.url)))
            if case!='missing':
                reg.capture(root,policy.key)
            if case=='bad_bytes':
                store.blob_path(root,original.sha256).write_bytes(b'changed test bytes')
        try:
            projection=proof.verify_contract(data,op['condition_id'],at,token=op['token_id'],scheduled=True)
            op.update(projection['intent_terms'])
        except (OSError,ValueError) as err:
            projection={'error':str(err)}
        formal=budget.replay(doc,data_dir=data,details=True)
        pending=budget.replay(doc,data_dir=data,details=True,entry_basis=research)
        a=pending['decisions'][0]; strict=formal['decisions'][0]
        row={'verify':projection.get('fee_basis',projection.get('error')),'formal':strict['outcome'],'research':a['outcome'],'proof_gaps':pending['proof_gaps']}
        if a['outcome']!='filled': return row
        market=market_archive.contracts(root,main['slug'],as_of=op['decision_at'])[0]
        seen=store.iso(store.instant(op['kickoff'])+timedelta(hours=5))
        for i,v in enumerate((1,0)):
            rec=terminal_row(market,i,v)
            sha=record_terminal(root,rec['token_id'],json.dumps({'data':[rec]}).encode(),seen)
            if not i:doc['redemptions']=[{**{k:op[k] for k in ('fixture_id','condition_id','token_id')},'id':'independent-final','at':seen,'original_sha256':sha}]
        actual=budget.replay(doc,data_dir=data,details=True,entry_basis=research)['leagues']['sea']
        basis=a['fee_evidence']['basis']
        lev,cost,net=charge_oracle(asset,round_in,quantum,{'up':ROUND_CEILING,'down':ROUND_DOWN,'half_up':ROUND_HALF_UP}[method])
        user_levels=[[D(x[k]) for k in ('price','size','fee_cash','fee_shares')] for x in a['fill']['levels']]
        account=actual['settled_paper_pnl_by_fee_basis'][basis]
        pnl=net-cost
        row.update(basis=basis,net=a['fill']['net_shares'],cash=a['cost_including_cash_fees'],redeemed=account['cash_from_redemptions'],
                   settled=account['settled_paper_pnl'],per_level=a['fill']['levels'],
                   oracle_matches=(lev==user_levels and D(a['cost_including_cash_fees'])==cost and D(a['fill']['net_shares'])==net
                     and D(account['cash_from_redemptions'])==net and D(account['settled_paper_pnl'])==pnl and D(actual['available_cash'])==D('2000')+pnl),
                   observed_native_fee=original_profile| (more or {}))
        return row

if __name__=='__main__':
    cases={'unregistered_shares':test('estimate'),'reviewed_cash':test('authority','cash','cash','.00001','down'),
           'reviewed_shares_cash_rounding':test('authority','shares','cash','.005','half_up'),
           'reviewed_shares_asset_rounding':test('authority','shares','charged','.001','half_up'),
           'reviewed_missing':test('missing'),'reviewed_bad_bytes':test('bad_bytes'),
           'reviewed_unknown_gamma_charge':test('authority',more={'additionalTakerCharge':0.14})}
    print(json.dumps(cases,indent=2))
