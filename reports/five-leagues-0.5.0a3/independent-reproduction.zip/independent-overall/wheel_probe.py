"""Build outside the frozen tree, install into an empty target, and compare packaged bytes."""
import hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
source=Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory() as work:
    work=Path(work)
    checkout=work/'source';checkout.mkdir()
    for fname in ('README.md','pyproject.toml'):shutil.copyfile(source/fname,checkout/fname)
    shutil.copytree(source/'src',checkout/'src',ignore=shutil.ignore_patterns('__pycache__','*.egg-info'))
    wheel_dir=work/'dist';target=work/'target'
    def proc(cmd,env=None):
        return subprocess.run(cmd,cwd=work,env=env,capture_output=True,text=True,check=True).stdout
    proc([sys.executable,'-m','pip','--disable-pip-version-check','wheel','--no-build-isolation','--no-deps','-w',str(wheel_dir),str(checkout)])
    wheel,=wheel_dir.glob('*.whl')
    proc([sys.executable,'-m','pip','--disable-pip-version-check','install','--no-deps','--target',str(target),str(wheel)])
    files={p.relative_to(source/'src').as_posix():p for p in (source/'src/polymarket861').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    with zipfile.ZipFile(wheel) as archive:
        names={x for x in archive.namelist() if x.startswith('polymarket861/') and not x.endswith('/')}
        assert set(files)==names,(set(files)-names,names-set(files))
        assert all(archive.read(name)==p.read_bytes()==(target/name).read_bytes() for name,p in files.items())
    env=dict(os.environ,PYTHONPATH=str(target),PYTHONDONTWRITEBYTECODE='1')
    version=proc([sys.executable,'-m','polymarket861','--version'],env).strip()
    cli=target/'bin/pm861'
    state=work/'untouched'
    output=json.loads(proc([str(cli),'--data-dir',str(state),'leagues','news-endpoints','preflight','--version','v2'],env))
    print(json.dumps({'version':version,'wheel_name':wheel.name,'checked_source_wheel_and_installed_files':len(files),'wheel_local_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),
                      'console_script_preflight':output['decision'],'new_state_directory_created':state.exists()},indent=2))
