"""A genuine a2 enrollment is reopened by a3, including a local plan drift negative control."""
import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
from tempfile import TemporaryDirectory
a2,a3=(Path(x).resolve()/'src' for x in sys.argv[1:3])
def command(src,data,*args):
    env=dict(os.environ,PYTHONPATH=str(src),PYTHONDONTWRITEBYTECODE='1')
    code="from polymarket861 import store; store.now_utc=lambda:'2026-11-26T11:00:00.000000Z'; from polymarket861.cli import main; raise SystemExit(main())"
    result=subprocess.run([sys.executable,'-c',code,'--data-dir',str(data),'leagues','news-endpoints',*args],env=env,capture_output=True,timeout=20)
    return result.returncode,hashlib.sha256(result.stdout).hexdigest(),json.loads(result.stdout) if result.stdout.strip() else result.stderr.decode().strip()
with TemporaryDirectory() as tmp:
    work=Path(tmp); data=work/'data'; changed=work/'changed'
    c0=command(a2,data,'register','--version','v2')
    reopened=command(a2,data,'register','--version','v2')
    r0=command(a2,data,'report','--version','v2')
    r1=command(a3,data,'report','--version','v2')
    c1=command(a3,data,'register','--version','v2')
    refused=command(a3,data,'register','--version','v2','--starts-at','2026-11-27T01:01:01Z')
    shutil.copytree(a3,changed)
    p=changed/'polymarket861/news_endpoint_v2.py'
    a='Before the fixed end publish only coverage'; b='Before the fixed end, publish only coverage'
    text=p.read_text();assert text.count(a)==1;p.write_text(text.replace(a,b))
    mutated={action:command(changed,data,action,'--version','v2') for action in ('preflight','report','register')}
    repaired=command(a3,data,'report','--version','v2')
    print(json.dumps({'issuer':'0.5.0a2','original_certificate':c0[2]['registration_sha256'],'original_sha':c0[2]['plan_sha256'],
                      'first_and_reopened_certificate_values_equal':c0[2]==reopened[2]==c1[2],
                      'a2_a3_reopened_certificate_bytes_equal':reopened[0]==c1[0]==0 and reopened[1]==c1[1],
                      'a2_a3_report_bytes_equal':r0[0]==r1[0]==0 and r0[1]==r1[1],
                      'changed_start':{'exit':refused[0],'error':refused[2]},
                      'changed_plan':{k:{'exit':v[0],'message':v[2]} for k,v in mutated.items()},
                      'restored_report_bytes_equal':r0[1]==repaired[1]},indent=2))
