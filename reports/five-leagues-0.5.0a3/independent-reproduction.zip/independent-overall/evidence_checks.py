"""Fail unless the independent release, chronology and ledger assertions hold."""
import hashlib,json,sys
from pathlib import Path
folder=Path(sys.argv[1]).resolve()
def read(name):
    return json.loads((folder/(name+'.json')).read_bytes())
assertions=[]
def claim(name,value):
    if not value:raise AssertionError(name)
    assertions.append(name)
w=read('watch-edges'); old=read('watch-a2')
claim('historical BUSY_SNAPSHOT reproduced',old['lock']['status']=='SQLITE_BUSY_SNAPSHOT' and old['lock']['event_rows']==0)
claim('WAL page and independent competitor both committed',w['lock']=={'journal':'wal','status':'complete','concurrent_commit_inside_page':False,'event_rows':2,'independent_writer_rows':1})
claim('worker failure logged and other fixture completed',w['workers']['first']=={'complete':1,'failed':1} and w['workers']['retry']=={'complete':1} and w['workers']['diagnostics']['count']==1)
for name,row in w['receipt_edges'].items():
    timely='0.999999' in name
    claim(name, len(row['clob_requests'])==2 and row['fixed_due']==2 and row['fixed_filled']==(2 if timely else 0) and row['pairs']==int(timely) and (timely or all(any('14 native CLOB token books arrived late at' in v and 'exclusive cutoff' in v for v in causes) for causes in row['gap_reasons'])))
for code, items in read('fatal').items():
    for key, row in items.items():claim(f'storage failure {code} in {key}',row['propagated'] and row['errno']==int(code) and row['injections']==1)
for key,row in read('catalog-pages').items():
    healthy=key in ('None','static')
    claim('dynamic catalogue '+key,row['healthy']==healthy and row['page_walk_complete']==healthy and row['jobs']==[['complete','explicit_pregame']] and (row['last_success'] is None or healthy or row['last_success']==row['prior_success']))
c=read('retry'); claim('six Claude recovery schedules',len(c['arms'])==6 and all(a['fixed_windows_complete']==2 and a['t1_pairs_complete']==1 for a in c['arms']))
o=read('overlap'); claim('actual concurrent scheduler',o['runs_in_which_watch_raised']==0 and o['background_refreshes_attempted']>0 and all(not r['raised'] and set(r['job_states'])=={'complete'} for r in o['per_run']))
p=read('fees')
for k,v in p.items():
    if k in ('reviewed_missing','reviewed_bad_bytes','reviewed_unknown_gamma_charge'):
        claim('rejected '+k,v['formal']==v['research']=='skipped_unverified_entry')
    else:
        claim('independent per-level fee and redemption '+k,v['oracle_matches'] and v['research']=='filled' and v['formal']==('skipped_unverified_entry' if k=='unregistered_shares' else 'filled'))
v=read('certificate'); claim('published a2 certificate and report',v['a2_a3_reopened_certificate_bytes_equal'] and v['a2_a3_report_bytes_equal'] and v['first_and_reopened_certificate_values_equal'])
claim('plan drift and immutable enroll',v['changed_start']['exit']==2 and v['restored_report_bytes_equal'] and all(r['exit']==2 and 'stored=' in r['message'] and 'current=' in r['message'] for r in v['changed_plan'].values()))
n=read('news')
claim('empty news state has no dataset',not n['empty_path_created'] and n['empty']['future'] is None and not n['empty']['windows'])
for cohort,expected in [('licensed_one_side','expected_ineligible'),('all_retainable_before_enrollment','unknown'),('registered_and_both_retainable','bound_news_originals_verified')]:
    rec=n[cohort]['observed']
    claim('news evidence '+cohort,rec['windows'][0]['state']==expected and not rec['write_attempts'] and rec['all_connections_read_only'] and rec['main_db_sha_unchanged'])
negative=n['registered_and_both_retainable']['away_blob_change']
claim('changed physical news bytes',negative['windows'][0]['state']=='expected_ineligible' and sorted(x[1] for x in negative['windows'][0]['fact_originals'])==['missing_or_invalid','verified'] and n['registered_and_both_retainable']['restored']['windows'][0]['state']=='bound_news_originals_verified')
s=read('process')
for case,code,state,cat in [('offline',1,'running','missing'),('dead_before_reap',1,'exited','missing'),('healthy_restart',0,'running','fresh'),('stale_with_live_process',1,'running','stale'),('after_int',1,'stopped','fresh'),('after_term',1,'stopped','fresh')]:
    rec=s[case];claim('real CLI '+case,(rec['exit'],rec['state'],rec['catalog_state'])==(code,state,cat))
claim('signals',s['kill_code']==-9 and s['inherited_ignored_sigint_code']==s['sigterm_code']==130)
x,y=read('b1-a2'),read('b1')
for key in ('matches','rounds','recipe','probabilities_sha256','training_views_sha256','old_seal_sha256','reopened_seal_payload_sha256'):
    claim('a2/a3 B1 '+key,x[key]==y[key])
claim('B1 release size',y['matches']==1900 and y['rounds']==190)
r=read('research-comment')
claim('raw research comment and manual waivers',r['research_changed'] and r['primary_equal'] and r['effective_club_keys_equal'] and r['waivers']==30 and r['all_have_reasons'])
claim('cross-Python scientific recipes',read('cross-minor')['parts_that_differ_between_interpreters']==[])
h=read('history');claim('historic replay published bytes',h['identical'])
f=read('faults');claim('56 external faults',f['cases']==f['watch_returned']==56 and f['watch_raised']==0)
print(json.dumps({'count':len(assertions),'passed':assertions},indent=2))
