"""Counterexamples for intermediate dynamic Gamma pages and the static sports taxonomy."""
from contextlib import ExitStack
from dataclasses import replace
from datetime import timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import json
from polymarket861 import big5_market as c, market_archive as a, market_provider as p, market_watch_health as h,store
import test_big5_market as f
cutoff=store.instant('2030-01-12T13:00Z')

def case(stale, repeat=False):
    with TemporaryDirectory() as tmp, ExitStack() as st:
        d=Path(tmp); wall=[cutoff-timedelta(minutes=12)]
        hook=[None] if repeat else [stale]
        requests=[]
        for m in (c,a,f,store):
            st.enter_context(patch.object(m,'now_utc',side_effect=lambda:store.iso(wall[0])))
        def upstream(url,params=None,**kw):
            response=f.gamma(url,params,**kw)
            page=params['offset'] if url.endswith('/events') else 'static' if url.endswith('/sports') else None
            old=hook[0] is not None and page is not None and (page==hook[0] or hook[0]=='all_dynamic' and page!='static')
            if page is not None:
                requests.append({'page':page,'stale':old})
            return replace(response,headers=dict(response.headers,age='586')) if old else response
        st.enter_context(patch.object(p,'get',side_effect=upstream))
        scope=(['sea'],*map(store.iso,(f.START,f.END)))
        with h.monitor(c.research_root(d),*scope,continuous=True,discover=True) as tick:
            if repeat:
                initial=c.catalog(d,['sea'],f.START,f.END,page_size=1)
                tick(1,initial)
                prior=h.status(c.research_root(d),*scope)['catalog_by_league']['sea']['last_success_at']
                hook[0]=stale
            else:
                prior=None
            wall[0]=cutoff-timedelta(seconds=20)
            result=c.catalog(d,['sea'],f.START,f.END,page_size=1)
            tick(2,result)
            live=h.status(c.research_root(d),*scope)
        wall[0]+=timedelta(milliseconds=100)
        jobs=c.watch(d,['sea'],f.START,f.END,discover=False)['last_jobs']
        return {'prior_success':prior,'seen_pages':requests,'page_walk_complete':result['leagues']['sea']['page_walk_complete'],
                'gaps':result['leagues']['sea']['gaps'],'healthy':live['healthy'],'catalog_state':live['catalog_state'],
                'last_success':live['catalog_by_league']['sea']['last_success_at'],
                'jobs':[(j['state'],j.get('exchange_state')) for j in jobs]}
if __name__=='__main__':
    print(json.dumps({str(k):case(k) for k in (None,'static',0,1,2,'all_dynamic')}|{'previous_success_then_old_middle':case(1,True)},indent=2))
