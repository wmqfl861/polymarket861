"""Exercise independent real collector processes with the public-HTTP fixture."""
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT=Path(sys.argv[1]).resolve()
env=dict(os.environ,PYTHONPATH=os.pathsep.join((str(ROOT/'.github/fixtures/watch-service'),str(ROOT/'src'))))
dates=['--start','2030-01-12T00:00Z','--end','2030-01-14T00:00Z']
result={}
with tempfile.TemporaryDirectory() as tmp:
    folder=Path(tmp); marker=folder/'offline'; env['PM861_CI_GAMMA_OFFLINE']=str(marker)
    base=[sys.executable,'-m','polymarket861','--data-dir',str(folder/'state'),'market']
    def check(*args):
        run=subprocess.run(base+['league-watchdog']+dates+list(args),env=env,capture_output=True,text=True,timeout=9)
        data=json.loads(run.stdout)
        return {'exit':run.returncode,**{k:data[k] for k in ('healthy','scheduler_alive','catalog_state','state','run_id','catalog_by_league')}}
    def new():
        ignore='import signal; signal.signal(signal.SIGINT, signal.SIG_IGN); from polymarket861.cli import main; raise SystemExit(main())'
        cmd=[sys.executable,'-c',ignore]+base[3:]+['league-watch']+dates+['--cycles','0']
        return subprocess.Popen(cmd,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    def wait(checking):
        stop=time.monotonic()+10
        while time.monotonic()<stop:
            state=check()
            if checking(state):return state
            time.sleep(.05)
        raise RuntimeError(state)
    marker.touch()
    a=new(); b=c=None
    try:
        result['offline']=wait(lambda d:d['scheduler_alive'])
        a.kill()
        # Test unreaped process before Popen.wait so /proc/state can be a zombie.
        result['dead_before_reap']=wait(lambda d:d['state']=='exited')
        result['kill_code']=a.wait(5)
        marker.unlink()
        b=new()
        result['healthy_restart']=wait(lambda d:d['healthy'])
        time.sleep(2.05)
        result['stale_with_live_process']=check('--max-catalog-age','1')
        result['scope_mismatch']=check('--league','epl')
        b.send_signal(signal.SIGINT)
        result['inherited_ignored_sigint_code']=b.wait(8)
        result['after_int']=check()
        c=new(); wait(lambda d:d['healthy'])
        c.terminate(); result['sigterm_code']=c.wait(8)
        result['after_term']=check()
    finally:
        for peer in (a,b,c):
            if peer is not None and peer.poll() is None:peer.kill();peer.wait(5)
    try:
        import socket
        with socket.socket(socket.AF_UNIX,socket.SOCK_DGRAM) as sock:
            sock.bind(str(folder/'review-notify.sock')); result['unix_datagram']='available'
    except OSError as error:result['unix_datagram']={'errno':error.errno,'error':str(error)}
result['pid_1']=Path('/proc/1/comm').read_text().strip()
print(json.dumps(result,indent=2))
