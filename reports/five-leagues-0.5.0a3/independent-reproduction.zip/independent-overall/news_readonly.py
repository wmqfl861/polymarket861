"""Read-only authorizer and expected coverage on native seals, with an independent raw-byte mutation."""
import hashlib,json,sqlite3,sys
from contextlib import closing
from datetime import timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from polymarket861 import news, news_endpoint_preflight as pre, news_endpoint_v2 as v2, news_endpoint_study as v1, news_sources, store
from test_news_endpoint_study import collect_native_seal
from test_news_endpoints_v2 import capture_clock
from test_news_matchday import AWAY,AWAY_RUMOUR,HOME,HOME_OUT,KICKOFF,add_club_feed,rss,seed_fixture
from test_paired_proof import at

CONNECT=sqlite3.connect
writers={sqlite3.SQLITE_INSERT,sqlite3.SQLITE_UPDATE,sqlite3.SQLITE_DELETE,sqlite3.SQLITE_CREATE_TABLE,
         sqlite3.SQLITE_CREATE_TRIGGER,sqlite3.SQLITE_DROP_TABLE,sqlite3.SQLITE_DROP_TRIGGER,sqlite3.SQLITE_ALTER_TABLE}
def original_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
def checked(root):
    attempts=[]; opens=[]
    def open_ro(target,*args,**kwargs):
        opens.append(str(target))
        db=CONNECT(target,*args,**kwargs)
        def guard(op,name,column,db_name,source):
            if op in writers and db_name=='main':
                attempts.append([op,name]);return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK
        db.set_authorizer(guard)
        return db
    p=root/'runtime.sqlite3'
    before=original_sha(p)
    with patch.object(sqlite3,'connect',side_effect=open_ro),patch.object(news_sources,'_get',side_effect=AssertionError('unexpected outbound request')):
        result=pre.preflight(root)
    windows=[{'state':w['news_evidence'],'binding':w['v2_binding'],'blockers':w['known_blockers'],
               'sides':{side:[(r['source'],r['raw_response_policy'],r['v2_original']) for r in entries['sources']] for side,entries in w['coverage'].items()},
               'fact_originals':[(x['source'],x['v2_original']) for x in w['fact_dependencies']]} for w in result['windows']]
    return {'decision':result['decision'],'registry':result['registration']['state'],'total':result['fixed_windows_total'],'checked':result['fixed_windows_checked'],
          'future':result['future_eligible_windows'],'main_db_sha_unchanged':before==original_sha(p),'write_attempts':attempts,
          'all_connections_read_only':all('?mode=ro' in path for path in opens),'connections':len(opens),'windows':windows}
def run(reg,restrict):
    with TemporaryDirectory() as tmp,capture_clock():
        root=Path(tmp)/'data'; hist=Path(tmp)/'history'
        with at('2026-08-01T10:00Z'):
            seed_fixture(root,hist)
            v1.enroll(root)
            if reg:v2.enroll(root)
            home,away=(add_club_feed(root,t) for t in (HOME,AWAY))
            if restrict:
                news.disable_feed(root,away['id'])
                away=news.add_feed(root,away|{'id':'restricted-away','license':'Derived facts only','url':'https://chelsea.example/licensed.xml'})
        kick=store.instant(KICKOFF)
        collect_native_seal(root,hist,{home['url']:rss(home,HOME_OUT),away['url']:rss(away,AWAY_RUMOUR)},kick-timedelta(minutes=95),kick-timedelta(minutes=61))
        with at(KICKOFF):
            result={'observed':checked(root)}
            if reg:
                with closing(CONNECT(root/'runtime.sqlite3')) as db:
                    sh=db.execute("SELECT DISTINCT response_sha FROM news_endpoint_v2_poll_originals WHERE source=?",(away['id'],)).fetchone()[0]
                p=store.blob_path(root,sh); b=p.read_bytes()
                p.write_bytes(b'not the archived publisher bytes')
                result['away_blob_change']=checked(root);p.write_bytes(b)
                result['restored']=checked(root)
            return result

if __name__=='__main__':
    artifact=json.loads((Path(sys.argv[1])/'reports/five-leagues-0.5.0a2/news-endpoint-study-v2.json').read_text())
    independently_packed = json.dumps(artifact['plan'],sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
    with TemporaryDirectory() as tmp:
        root=Path(tmp)/'still-absent'
        out={'a2_plan_sha256':hashlib.sha256(independently_packed).hexdigest(),'a3_plan_sha256':v2.published_proposal()['plan_sha256'],
             'empty':checked(root),'empty_path_created':root.exists()}
    out['licensed_one_side']=run(False,True)
    out['all_retainable_before_enrollment']=run(False,False)
    out['registered_and_both_retainable']=run(True,False)
    print(json.dumps(out,indent=2))
