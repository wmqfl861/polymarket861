"""Compare full research-recipe bytes and primary B1 across a harmless comment in a source copy."""
import hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
repo=Path(sys.argv[1]).resolve()
def run(src):
    code="""import json;from polymarket861 import football,league_registry,league_study,store,pipeline
manifest={s:league_registry.source_blobs(s) for s in ('epl','lal','bun','sea','fl1')}
r=league_study.research_recipe(manifest)
print(json.dumps({'research':r['sha256'],'primary':store.digest(pipeline._build_recipe('B1',football.DEFAULT_LINES)),'effective':r['manifest']['effective_club_keys_sha256']}))"""
    return json.loads(subprocess.check_output([sys.executable,'-c',code],env=dict(os.environ,PYTHONPATH=str(src),PYTHONDONTWRITEBYTECODE='1')))
with tempfile.TemporaryDirectory() as work:
    root=Path(work)/'src';shutil.copytree(repo/'src',root)
    before=run(root); p=root/'polymarket861/league_registry.py'
    p.write_text(p.read_text()+'\n# Independent reviewer comment.\n')
    after=run(root)
    policy=repo/'scripts/recipe-reference-policy.json'
    approved=json.loads(policy.read_bytes())
    print(json.dumps({'before':before,'after':after,'primary_equal':before['primary']==after['primary'],'research_changed':before['research']!=after['research'],
                      'effective_club_keys_equal':before['effective']==after['effective'],'waivers':len(approved),'all_have_reasons':all(v['reason'].strip() for v in approved.values()),
                      'policy_sha256':hashlib.sha256(policy.read_bytes()).hexdigest()},indent=2))
