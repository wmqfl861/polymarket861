"""Inject an OS archive failure at the actual storage call, beyond the watcher entry."""
import errno
import json
from contextlib import ExitStack
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from polymarket861 import big5_market as big5, market_archive as archive, market_provider as provider, store
import test_big5_market as fixture


def attempt(operation, error_code=errno.ENOSPC):
    clock = ['2030-01-12T12:59:40.000000Z']
    failures = []
    write = archive.archive_bytes

    def wrapped(*args, **kwargs):
        op = kwargs['metadata']['operation']
        if op == operation:
            failures.append(op)
            raise OSError(error_code, 'independently injected storage failure')
        return write(*args, **kwargs)

    with TemporaryDirectory() as folder, ExitStack() as ctl:
        data = Path(folder)
        for module in (fixture, store, archive, big5):
            ctl.enter_context(patch.object(module, 'now_utc', side_effect=lambda: clock[0]))
        ctl.enter_context(patch.object(provider, 'get', side_effect=fixture.gamma))
        if operation == 'books':
            big5.catalog(data, ['sea'], fixture.START, fixture.END)
        ctl.enter_context(patch.object(archive, 'archive_bytes', side_effect=wrapped))
        try:
            result = big5.watch(data, ['sea'], fixture.START, fixture.END, cycles=1, discover=operation != 'books')
            return {'propagated':False, 'injections':len(failures),'states': result['states'],
                    'discovery_gaps':((result.get('discovery') or {}).get('leagues') or {}).get('sea', {}).get('gaps'),
                    'jobs':[{'phase':j['phase'],'state':j['state'],'batch_error':j.get('batch_error')} for j in result['last_jobs']]}
        except Exception as exc:
            return {'propagated': True, 'injections':len(failures),'type':type(exc).__name__,'errno':getattr(exc,'errno',None),'message':str(exc)}

if __name__ == '__main__':
    print(json.dumps({str(error):{op:attempt(op,error) for op in ('league_sports','league_catalog','books')} for error in (errno.ENOSPC,errno.EIO)},indent=2))
