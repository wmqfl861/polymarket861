"""Reviewer checks, use PYTHONPATH=<candidate>/src:<candidate>/tests. No external IO."""
import json
import sqlite3
import threading
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack, closing
from dataclasses import replace
from datetime import timedelta
from email.utils import format_datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from urllib.parse import urlencode
import test_big5_market as transport
from polymarket861 import big5_market as collector, market_archive as archive, market_provider as provider, store


def locks():
    with TemporaryDirectory() as folder, ExitStack() as control:
        data = Path(folder)
        root = collector.research_root(data)
        with closing(collector._db(root)) as conn:
            journal = conn.execute("PRAGMA journal_mode").fetchone()[0]
        got_read, written, scheduled = threading.Event(), threading.Event(), threading.Event()
        first = []
        held_open = []
        write_event = collector._record
        def after_catalog_read(conn, *args):
            if not first:
                first.append(True)
                conn.execute("SELECT count(*) FROM big5_events").fetchone()
                got_read.set()
                assert scheduled.wait(4)
                held_open.append(written.wait(.40))
            return write_event(conn, *args)
        def other_writer():
            assert got_read.wait(6)
            with closing(sqlite3.connect(root / 'runtime.sqlite3', timeout=5)) as conn, conn:
                scheduled.set()
                conn.execute("BEGIN IMMEDIATE")
                conn.execute("INSERT INTO big5_last_dispatch VALUES('independent','test','2030-01-12T12:50Z')")
            written.set()
        control.enter_context(patch.object(provider, 'get', side_effect=transport.gamma))
        control.enter_context(patch.object(collector, '_record', side_effect=after_catalog_read))
        with ThreadPoolExecutor(max_workers=1) as pool:
            other = pool.submit(other_writer)
            try:
                out = collector.catalog(data, ['sea'], transport.START, transport.END)['leagues']['sea']
                status = 'complete' if out['page_walk_complete'] else 'incomplete'
            except sqlite3.Error as exc:
                status = getattr(exc,'sqlite_errorname',str(exc))
            other.result(timeout=6)
        with closing(collector._db(root)) as conn:
            events = conn.execute('SELECT count(*) FROM big5_events').fetchone()[0]
            competitor = conn.execute("SELECT count(*) FROM big5_last_dispatch WHERE fixture='independent'").fetchone()[0]
        return dict(journal=journal,status=status,concurrent_commit_inside_page=held_open[0],
                    event_rows=events,independent_writer_rows=competitor)


def receipt_edge(hours, delta, stale=False, old_cache=False):
    cutoff = store.instant(transport.DAY + 'T14:00Z') - timedelta(hours=hours)
    wall = [cutoff - timedelta(seconds=810 if stale else 50)]
    requests = []
    def upstream(url, params=None, **kwargs):
        response = transport.gamma(url, params, **kwargs)
        if '/events' in url and old_cache:
            return replace(response,headers=dict(response.headers, age='3600'))
        if not url.endswith('/books'):
            return response
        start = wall[0]
        wall[0] += timedelta(seconds=delta)
        finish = wall[0]
        requests.append([store.iso(start),store.iso(finish)])
        return replace(response,received_at=store.iso(finish),headers={'date': format_datetime(finish)})
    with TemporaryDirectory() as folder, ExitStack() as ctl:
        data = Path(folder)
        for module in (transport,collector,archive,store):
            ctl.enter_context(patch.object(module, 'now_utc', side_effect=lambda: store.iso(wall[0])))
        ctl.enter_context(patch.object(provider, 'get', side_effect=upstream))
        collector.catalog(data,['sea'],transport.START,transport.END)
        legs = []
        for start in (-1, 9):
            wall[0] = cutoff + timedelta(seconds=start)
            leg = collector.watch(data,['sea'],transport.START,transport.END, discover=False)['last_jobs'][0]
            legs.append((leg['phase'],leg['state'],leg.get('received'),leg.get('exchange_state')))
        wall[0] = cutoff + timedelta(seconds=30)
        report = collector.weekly_report(data,store.iso(cutoff-timedelta(seconds=25)),store.iso(wall[0]))
        counts = report['by_league']['sea']
        return dict(legs=legs,clob_requests=requests,fixed_due=counts['fixed_windows_due'],
                    fixed_filled=counts['fixed_windows_complete'],pairs=counts.get('t%d_pairs_complete'%hours,0),
                    gap_reasons=[g['reasons'] for g in report.get('fixed_window_gaps',[])])


def peer_failure():
    cutoff = store.instant(transport.DAY + 'T12:59:42Z')
    now = [cutoff]
    by_tag = {tag:code for code,(_,tag) in collector.MARKETS.items()}
    def upstream(url, params=None, **kwargs):
        if not url.endswith(('/sports','/events')):
            return transport.gamma(url,params,**kwargs)
        reply = transport.gamma(url, {'tag_id':'101962','limit':25,'offset':0} if url.endswith('/events') else {}, **kwargs)
        if url.endswith('/sports'):
            value = [{'sport':code,'series':collector.MARKETS[code][0],'tags':collector.MARKETS[code][1],'primaryTagId':collector.MARKETS[code][1]} for code in ('sea','bun')]
        else:
            code = by_tag[str(params['tag_id'])]
            value = [transport.native(league=code),transport.native(True,league=code)]
            if code=='bun':
                for e in value:
                    e['id']=str(int(e['id'])+100)
                    for m in e['markets']:
                        old=int(m['conditionId'],16)
                        m['conditionId']='0x'+format(old+100,'064x')
                        m['clobTokenIds']=[str(int(t)+1000) for t in m['clobTokenIds']]
        return replace(reply,body=json.dumps(value).encode(),url=url + ('?' + urlencode(params) if params else ''))
    capture = archive.capture
    def flaky(root, fixture, **kwargs):
        if fixture.startswith('sea-'):
            raise RuntimeError('independent sample failure')
        return capture(root,fixture,**kwargs)
    with TemporaryDirectory() as folder, ExitStack() as ctl:
        data = Path(folder)
        for module in (transport,collector,archive,store):
            ctl.enter_context(patch.object(module,'now_utc',side_effect=lambda:store.iso(now[0])))
        ctl.enter_context(patch.object(provider,'get',side_effect=upstream))
        collector.catalog(data,['sea','bun'],transport.START,transport.END)
        with patch.object(archive,'capture',side_effect=flaky):
            try:
                states1=collector.watch(data,['sea','bun'],transport.START,transport.END,discover=False)['states']
            except Exception as exc:
                return {'escape':type(exc).__name__, 'detail':str(exc)}
        now[0]+=timedelta(seconds=3)
        states2=collector.watch(data,['sea','bun'],transport.START,transport.END,discover=False)['states']
        rpt=collector.weekly_report(data,store.iso(cutoff-timedelta(seconds=30)),store.iso(now[0]+timedelta(seconds=1)))
        return {'first':states1,'retry':states2,'diagnostics':rpt.get('collector_task_failures')}

if __name__=='__main__':
    cases = {f'T-{hours}/receive_after_{delta}s':receipt_edge(hours,delta,stale=True)
             for hours in (1,24) for delta in (.999999,1.0,1.000001)}
    print(json.dumps({'lock':locks(),'workers':peer_failure(),'receipt_edges':cases},indent=2))
